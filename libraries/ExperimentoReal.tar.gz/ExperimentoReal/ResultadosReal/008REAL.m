# Created by Octave 4.2.2, Thu Dec 03 11:06:41 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
008


# name: age
# type: sq_string
# elements: 1
# length: 2
27


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 2 3 1 4 5 6


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 0.3652632236480713
 0.2475559711456299
 0.2228929996490479
 0.1320531368255615
 0.1538870334625244
 0.1430778503417969


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.210788369178772


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.3443009853363037
 0.1876289844512939
 0.2545499801635742
 0.2100479602813721
 0.1487269401550293
 0.3835930824279785
 0.2881741523742676
 0.2155330181121826
 0.2718400955200195
 0.1984789371490479
 0.1726551055908203
 0.1038439273834229
 0.1649339199066162
 0.1655769348144531
 0.1442921161651611
 0.1329159736633301
 0.05355000495910645
 0.9074320793151855
 0.377979040145874
 0.3885879516601562
 0.2882740497589111
 0.2879629135131836
 0.1824781894683838
 0.181657075881958
 0.2899959087371826
 0.182729959487915
 0.1704399585723877
 0.2496452331542969
 0.1879119873046875
 0.3451111316680908
 0.3669350147247314
 0.1089470386505127
 0.2206370830535889
 0.3721721172332764
 0.3160450458526611
 0.2458407878875732
 0.237713098526001
 0.2452800273895264
 0.2385458946228027
 0.2771081924438477
 0.1499569416046143
 0.04771208763122559
 0.2319729328155518
 0.1891040802001953
 0.1767280101776123
 0.2661628723144531
 0.1946589946746826
 0.0868220329284668
 0.2375719547271729
 0.1202621459960938
 0.1426329612731934
 0.2041962146759033
 0.1090819835662842
 0.1761481761932373
 0.2267129421234131
 0.08659505844116211
 0.08670401573181152
 0.321760892868042
 0.2693908214569092
 0.2829060554504395
 0.1485559940338135
 0.2715470790863037
 0.2376291751861572
 0.1984379291534424
 0.1092848777770996
 0.2823379039764404
 0.2718691825866699
 0.1593508720397949
 0.3390970230102539
 0.1259100437164307
 0.1093788146972656
 0.1093668937683105
 0.1774451732635498
 0.1102180480957031
 0.1649689674377441
 0.1886129379272461
 0.1036150455474854
 0.1256630420684814
 0.2044708728790283
 0.02669310569763184
 0.2213389873504639
 0.2329051494598389
 0.2385668754577637
 0.1929540634155273
 0.5509729385375977
 0.1986629962921143
 0.3167240619659424
 0.1707448959350586
 0.02532601356506348
 0.1427040100097656
 0.1611490249633789
 0.1036851406097412
 0.187654972076416
 0.1536900997161865
 0.09786796569824219
 0.04899215698242188
 0.1315920352935791
 3.605139017105103
 0.1594359874725342
 0.3282618522644043
 0.1826839447021484
 0.1930429935455322
 0.243351936340332
 0.09958100318908691
 0.1952159404754639
 0.2100830078125
 0.2450380325317383
 0.3558759689331055
 0.3002030849456787
 0.1593949794769287
 0.165395975112915
 0.2833969593048096
 0.1202850341796875
 0.2670650482177734
 0.1817841529846191
 0.05301809310913086
 0.08660602569580078
 0.05906105041503906
 0.07660889625549316
 0.211313009262085
 0.2098031044006348
 0.1202709674835205
 0.3445229530334473
 0.2829811573028564
 0.2604050636291504
 0.07558584213256836
 0.09267115592956543
 0.03169608116149902
 2.423464059829712
 0.3452398777008057
 0.3014070987701416
 0.2890489101409912
 0.2211790084838867
 0.09235191345214844
 0.1891129016876221
 0.03536391258239746
 0.4224200248718262
 0.176023006439209
 0.3380861282348633
 0.2831020355224609
 0.3892018795013428
 0.3057489395141602
 0.2991390228271484
 0.2606790065765381
 0.2996768951416016
 0.2381119728088379
 0.3169119358062744
 0.2713179588317871
 0.181793212890625
 0.2712991237640381
 1.794084072113037
 0.3662309646606445
 0.4392099380493164
 0.2770750522613525
 0.2489538192749023
 0.2439351081848145
 0.3719480037689209
 0.2501380443572998
 0.1549289226531982
 0.2045228481292725
 0.1985208988189697
 0.1888999938964844
 0.1553189754486084
 0.1654460430145264
 0.1593570709228516
 0.2990429401397705
 0.3275611400604248
 0.2839248180389404
 0.3217790126800537
 0.3352830410003662
 0.2155458927154541
 0.2993769645690918
 0.1262328624725342
 0.1819050312042236
 0.3387930393218994
 0.1258540153503418
 0.1090579032897949
 0.1945059299468994
 0.1493179798126221
 0.2336459159851074
 0.1936318874359131
 0.149014949798584
 0.1092431545257568
 0.2100920677185059
 0.1154038906097412
 0.1426730155944824
 0.2600388526916504
 0.288038969039917
 0.1649439334869385
 0.2659649848937988
 0.1315269470214844
 0.008461952209472656
 0.3504939079284668
 0.2213981151580811
 0.03645992279052734
 0.3002967834472656
 0.09233689308166504
 0.1819849014282227
 0.22794508934021
 0.1260228157043457
 0.2387821674346924
 0.2161350250244141
 0.1716079711914062
 0.2886149883270264
 0.1944098472595215
 0.2879009246826172
 0.2769758701324463
 0.2545549869537354
 0.3167641162872314
 0.2951288223266602
 0.2152059078216553
 0.1650669574737549
 0.1930320262908936
 0.2821979522705078
 0.05858707427978516
 0.2717430591583252
 0.1653749942779541
 0.1488111019134521
 0.1764740943908691
 0.2435359954833984
 0.1383399963378906
 0.07086586952209473
 0.05856919288635254
 0.1704437732696533
 0.1147119998931885
 0.2825350761413574
 0.04350399971008301
 0.02504682540893555
 0.1538259983062744
 1.773708820343018
 0.3833391666412354
 0.7948369979858398
 0.03101015090942383
 0.3162050247192383
 0.4123780727386475
 0.2824759483337402
 0.4130549430847168
 0.6741471290588379
 0.1762230396270752
 0.2616100311279297
 0.2330729961395264
 0.1650958061218262
 0.06456995010375977
 0.2604508399963379
 0.2546749114990234
 0.2545912265777588
 0.1822540760040283
 0.1051080226898193
 0.1203949451446533
 0.1224210262298584
 0.04347681999206543
 0.3331148624420166
 0.2440710067749023
 0.2444980144500732
 0.3329770565032959
 0.3279049396514893
 0.08684086799621582
 0.1592888832092285
 0.2769370079040527
 0.1035909652709961
 0.1659600734710693
 0.204571008682251
 0.0306708812713623
 0.1033809185028076
 0.1989710330963135
 0.02592611312866211
 1.797865867614746
 0.1046590805053711
 0.1561048030853271
 0.053192138671875
 0.3724918365478516
 0.0475161075592041
 0.1328930854797363
 0.2671728134155273
 0.2153711318969727
 0.2313041687011719
 0.2009818553924561
 0.2434871196746826
 0.2325930595397949
 0.2885122299194336
 0.2046408653259277
 0.2385098934173584
 0.2441780567169189
 0.05335402488708496
 0.2219688892364502
 0.3778550624847412
 0.08110499382019043
 0.2435159683227539
 0.05870795249938965
 0.0420379638671875
 0.01395511627197266
 0.1706008911132812
 1.612283945083618
 0.0367119312286377
 0.2733120918273926
 0.08165502548217773
 0.04345297813415527
 0.3270208835601807
 0.03692078590393066
 1.73557710647583
 0.3169999122619629
 0.2937290668487549
 0.2047750949859619
 0.1090219020843506
 0.1156258583068848
 0.2376670837402344
 0.1149799823760986
 0.06434082984924316
 0.2209658622741699
 0.2101109027862549
 0.05298304557800293
 1.604532957077026
 0.1033928394317627
 0.04801201820373535
 0.05431795120239258
 0.1823627948760986
 1.358142852783203
 0.06994891166687012
 0.3333039283752441
 0.00871586799621582
 0.04391002655029297
 0.2719559669494629
 0.03646087646484375
 0.008470058441162109
 0.08813381195068359
 1.34312891960144
 0.1037499904632568
 0.1873469352722168
 0.03643107414245605
 0.1985352039337158
 0.2602298259735107
 0.05324912071228027
 1.341500997543335
 0.1715831756591797
 0.1205770969390869
 0.2156860828399658
 0.2162141799926758
 0.1259829998016357
 0.2378599643707275
 0.08865809440612793
 1.546422958374023
 0.271651029586792
 0.294111967086792
 0.06100916862487793
 0.07008218765258789
 0.1713027954101562
 1.296005010604858
 0.5068230628967285
 0.1947300434112549
 0.1601831912994385
 0.2213540077209473
 0.1597211360931396
 1.467040061950684
 0.07175016403198242
 0.3384010791778564
 0.04930901527404785
 0.04353499412536621
 0.1477339267730713
 1.341174840927124
 0.2446630001068115
 0.2824020385742188
 0.1257808208465576
 0.143172025680542
 0.1427550315856934
 0.01950216293334961
 0.03729486465454102
 0.1985518932342529
 0.03067708015441895
 0.4112560749053955
 0.4838399887084961
 0.08698606491088867
 0.366940975189209
 0.1044411659240723
 1.470485210418701
 0.1033928394317627
 0.2994019985198975
 0.05326485633850098
 0.2658729553222656
 0.08665609359741211
 0.2935061454772949
 0.2768561840057373
 0.1817440986633301
 0.4395937919616699
 0.3560061454772949
 0.2048358917236328
 0.1988589763641357
 0.2776451110839844
 0.1034188270568848
 0.04342508316040039
 0.0417630672454834
 0.2604711055755615
 0.008656978607177734
 0.1113150119781494
 0.1642711162567139
 0.01963090896606445
 0.04439401626586914
 0.1043012142181396
 0.008417844772338867
 1.612806081771851
 0.1547811031341553
 0.07039618492126465
 0.1539371013641357
 0.05300498008728027
 0.008372068405151367
 0.2389929294586182
 0.03684496879577637
 0.04352378845214844
 0.1768181324005127
 0.1092050075531006
 1.379668951034546
 0.372492790222168
 0.1986842155456543
 0.09265518188476562
 0.2378079891204834
 0.1715290546417236
 0.07594513893127441
 0.2559700012207031
 0.2442409992218018
 1.324079990386963
 0.09892892837524414
 0.1427791118621826
 0.03604793548583984
 0.1273999214172363
 0.0980839729309082
 0.03060317039489746
 1.016052961349487
 0.05309104919433594
 0.8027060031890869
 0.00837397575378418
 0.1650400161743164
 1.355262041091919
 1.917616844177246
 0.36649489402771
 0.115868091583252
 0.0474998950958252
 0.3626580238342285
 0.05334711074829102
 0.3105289936065674
 0.1985659599304199
 0.344041109085083
 0.2941598892211914
 0.3282809257507324
 0.3505508899688721
 0.4015021324157715
 0.3444650173187256
 0.2937371730804443
 0.3440978527069092
 0.2545778751373291
 0.2321250438690186
 0.08717179298400879
 0.3730320930480957
 0.2832541465759277
 0.3604600429534912
 0.1816551685333252
 0.1859779357910156
 0.2833588123321533
 0.1651201248168945
 0.0755469799041748
 0.2113640308380127
 0.1203639507293701
 0.07588291168212891
 0.1091899871826172
 0.2160751819610596
 0.09992790222167969
 0.03078603744506836
 0.1944739818572998
 0.1095139980316162
 0.04772806167602539
 0.1482031345367432
 0.01396393775939941
 0.1037781238555908
 0.05917119979858398
 0.03080582618713379
 0.03812813758850098
 0.1597981452941895
 0.05317091941833496
 0.008540868759155273
 0.1315350532531738
 0.04293417930603027
 0.1888060569763184
 0.2657558917999268
 0.1717400550842285
 0.09847903251647949
 0.03633308410644531
 1.46955394744873
 0.2940990924835205
 0.2211248874664307
 0.04228115081787109
 0.2325139045715332
 0.148245096206665
 0.09351611137390137
 0.126187801361084
 0.1878960132598877
 0.5235440731048584
 0.2169690132141113
 0.2111480236053467
 0.1484689712524414
 0.2445878982543945
 0.1933541297912598
 0.4838747978210449
 0.2380120754241943
 0.1718959808349609
 0.05349111557006836
 1.357318878173828
 0.09807515144348145
 0.05323386192321777
 0.3068888187408447
 0.1048719882965088
 0.05305910110473633
 0.1984639167785645
 0.2657699584960938
 0.004016876220703125
 0.1493852138519287
 0.09237003326416016
 0.09251880645751953
 0.3111269474029541
 0.2156648635864258
 0.1428349018096924
 0.1552591323852539
 0.105118989944458
 0.01416993141174316
 1.366205930709839
 0.1145250797271729
 0.0929410457611084
 1.466192007064819
 0.08110880851745605
 0.07621216773986816
 1.234799146652222
 0.3387370109558105
 0.03109407424926758
 0.1434500217437744
 0.07554411888122559
 0.1763300895690918
 0.3663949966430664
 0.1481919288635254
 0.08707809448242188
 0.1987700462341309
 0.1090011596679688
 0.03622913360595703
 0.3986649513244629
 0.13720703125
 0.009860992431640625
 1.252204895019531
 1.201498985290527
 0.3448221683502197
 0.05322098731994629
 0.1612560749053955
 0.1150400638580322
 0.1202309131622314
 0.2112371921539307
 0.1595809459686279
 0.2775459289550781
 0.215627908706665
 0.1650359630584717
 0.2382059097290039
 0.1708889007568359
 0.1764659881591797
 0.1035521030426025
 0.08668994903564453
 0.09353208541870117
 1.45969295501709
 0.1874170303344727
 0.05314087867736816
 0.02522897720336914
 0.07691597938537598
 0.2375719547271729
 0.01449704170227051
 0.2324228286743164
 0.1319670677185059
 0.2321889400482178
 0.1257550716400146
 0.09334301948547363
 0.1314749717712402
 0.1984729766845703
 0.1314051151275635
 0.1036210060119629
 0.2263891696929932
 0.2935659885406494
 0.176347017288208
 0.1440918445587158
 0.1818640232086182
 0.1317028999328613
 0.2656681537628174
 0.07627987861633301
 0.2096748352050781
 0.2098040580749512
 0.1037299633026123
 0.272162914276123
 0.1935949325561523
 0.1485700607299805
 0.5334939956665039
 0.1650340557098389
 1.482024908065796
 0.6194779872894287
 0.1848330497741699
 0.1553058624267578
 0.3628458976745605
 0.2828941345214844
 0.1987800598144531
 0.2619049549102783
 0.1712329387664795
 0.2055389881134033
 0.176163911819458
 0.09325504302978516
 0.04793906211853027
 0.2832851409912109
 0.1257369518280029
 0.2940549850463867
 0.294058084487915
 0.1537330150604248
 0.109637975692749
 0.1550569534301758
 0.5605170726776123
 0.09226298332214355
 0.1163120269775391
 0.09795379638671875
 0.2660670280456543
 0.2717628479003906
 0.1209969520568848
 0.06025385856628418
 0.0868990421295166
 0.2543430328369141
 0.149583101272583
 0.0708620548248291
 0.2729740142822266
 0.1817810535430908
 0.07552814483642578
 0.1318471431732178
 0.1538660526275635
 0.1480839252471924
 0.09231996536254883
 0.3341720104217529
 0.1485741138458252
 0.1933040618896484
 0.1427879333496094
 0.110152006149292
 0.1487879753112793
 0.2441060543060303
 0.1991369724273682
 0.1707651615142822
 0.1543829441070557
 0.2327678203582764
 0.1091420650482178
 0.09910798072814941
 0.1381821632385254
 0.160228967666626
 0.1427750587463379
 0.06402802467346191
 0.2275359630584717
 0.1091008186340332
 0.03777694702148438
 0.1320610046386719
 0.0645601749420166
 0.2098269462585449
 0.1709620952606201
 0.2607119083404541
 0.322545051574707
 0.09801983833312988
 0.1710469722747803
 0.1987040042877197
 0.2713818550109863
 0.3232312202453613
 0.4064981937408447
 0.3552818298339844
 0.1430540084838867
 0.216933012008667
 0.1930420398712158
 0.01993203163146973
 0.1883149147033691
 0.148806095123291
 0.1259450912475586
 0.2385509014129639
 0.2199969291687012
 0.1728031635284424
 0.2211599349975586
 0.2046182155609131
 0.1710360050201416
 0.1988499164581299
 0.1649398803710938
 0.1210689544677734
 0.4334590435028076
 0.2044541835784912
 0.02676200866699219
 0.3775479793548584
 0.1045479774475098
 0.08662605285644531
 0.10359787940979
 0.2268848419189453
 0.1819849014282227
 0.1878559589385986
 0.1372208595275879
 0.1425108909606934
 0.1487629413604736
 0.1540849208831787
 0.1034319400787354
 0.3328509330749512
 0.2001569271087646
 0.1655049324035645
 0.08277606964111328
 0.1372590065002441
 0.1158530712127686
 0.1487669944763184
 0.3401200771331787
 0.1370711326599121
 0.2603230476379395
 0.3557848930358887
 0.327092170715332
 0.2548420429229736
 0.1481399536132812
 0.2379341125488281
 0.1481311321258545
 0.3102350234985352
 0.08677577972412109
 0.3619561195373535
 0.1154470443725586
 0.0206758975982666
 0.2499680519104004
 0.1372780799865723
 0.09962582588195801
 0.1888091564178467
 0.1379539966583252
 0.1093170642852783
 0.2835450172424316
 0.1762630939483643
 0.1484889984130859
 0.2061018943786621
 0.1090340614318848
 0.1093900203704834
 0.09961104393005371
 0.2208859920501709
 0.2995560169219971
 0.03679895401000977
 0.1723020076751709
 0.1653690338134766
 0.2210700511932373
 0.08147215843200684
 0.1647059917449951
 0.07033491134643555
 0.1318769454956055
 0.1596558094024658
 0.06032800674438477
 0.2494058609008789
 0.1988799571990967
 0.2545790672302246
 0.3627638816833496
 0.3231208324432373
 0.3725039958953857
 0.3514211177825928
 0.2207329273223877
 0.3772580623626709


# name: avgTeste
# type: scalar
0.2459231481552124


# name: antecipatedresponseT
# type: matrix
# rows: 0
# columns: 0


