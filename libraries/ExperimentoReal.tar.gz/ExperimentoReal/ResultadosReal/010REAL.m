# Created by Octave 4.2.2, Wed Dec 09 19:29:30 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
010


# name: age
# type: sq_string
# elements: 1
# length: 2
23


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 4 2 6 3 1 5


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 0.3375439643859863
 0.283473014831543
 0.165316104888916
 0.2517499923706055
 0.1095418930053711
 0.0868079662322998


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.2057388226191203


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 3
 3 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 3
 3 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 5
 2 2 2 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 4
 2 2 3 1


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 4.964096069335938
 0.2392020225524902
 0.3885438442230225
 0.2049839496612549
 0.2211787700653076
 0.07053709030151367
 0.09858489036560059
 0.1035749912261963
 1.684669971466064
 0.1260149478912354
 0.3078670501708984
 1.489364147186279
 0.1090121269226074
 0.07017397880554199
 0.07024884223937988
 0.07637500762939453
 1.060919046401978
 0.2814168930053711
 0.2943391799926758
 1.251368999481201
 0.3767328262329102
 0.1824688911437988
 0.08709287643432617
 0.04192709922790527
 0.05858898162841797
 1.089500904083252
 1.563329935073853
 0.0983431339263916
 1.076736927032471
 0.08679986000061035
 0.03646707534790039
 1.425609111785889
 0.3104310035705566
 0.1985569000244141
 0.01373791694641113
 0.08680415153503418
 0.1539828777313232
 0.05899405479431152
 1.405515909194946
 0.09245181083679199
 0.05321097373962402
 0.03700590133666992
 0.03138494491577148
 1.139190912246704
 0.08115696907043457
 0.03640413284301758
 0.03664207458496094
 0.103626012802124
 0.04850101470947266
 0.05310893058776855
 0.0429539680480957
 0.05351495742797852
 0.01955604553222656
 0.04770898818969727
 0.03077316284179688
 1.259351015090942
 0.2576780319213867
 0.0586240291595459
 1.392014026641846
 0.3473958969116211
 0.1721129417419434
 0.07647800445556641
 0.0314178466796875
 0.04347014427185059
 0.1320359706878662
 0.1101858615875244
 0.03081893920898438
 0.03077507019042969
 0.03717303276062012
 0.008760929107666016
 1.252887010574341
 0.08107900619506836
 0.03673791885375977
 0.9889500141143799
 0.1093199253082275
 0.03077006340026855
 0.008267879486083984
 0.08737587928771973
 0.009061098098754883
 0.03106403350830078
 0.08674192428588867
 0.09269189834594727
 1.127495050430298
 0.1204249858856201
 0.09223294258117676
 1.196242094039917
 0.1214940547943115
 0.1092631816864014
 1.13357400894165
 0.3231680393218994
 0.137394905090332
 0.01416802406311035
 0.0701138973236084
 1.228605031967163
 0.0642390251159668
 0.1036999225616455
 0.0699150562286377
 0.01393580436706543
 0.09786415100097656
 0.02016592025756836
 1.162887096405029
 0.05384087562561035
 0.01955294609069824
 0.008247852325439453
 0.2329530715942383
 0.2241439819335938
 1.144830942153931
 0.05332589149475098
 0.03105521202087402
 0.03632211685180664
 0.05420398712158203
 0.01665306091308594
 0.05374908447265625
 0.1265368461608887
 0.01988506317138672
 0.182304859161377
 0.08717203140258789
 1.219999074935913
 1.252345085144043
 0.3257749080657959
 0.2775177955627441
 1.36768102645874
 0.143402099609375
 0.06422901153564453
 0.109004020690918
 0.08207011222839355
 0.0143120288848877
 0.02054786682128906
 0.1540100574493408
 0.02571392059326172
 1.062827110290527
 0.1428561210632324
 0.01995015144348145
 0.01441717147827148
 0.08180713653564453
 1.274734020233154
 0.03088188171386719
 0.08748006820678711
 0.08775019645690918
 1.267913818359375
 0.2547831535339355
 0.1487219333648682
 0.09310579299926758
 0.131648063659668
 0.13232421875
 0.003383159637451172
 1.381498098373413
 0.1208491325378418
 1.062114000320435
 0.3107929229736328
 0.6069560050964355
 0.08698606491088867
 0.0868840217590332
 0.07554316520690918
 1.098676919937134
 0.1762320995330811
 0.08897995948791504
 0.01973795890808105
 0.09367513656616211
 0.02546286582946777
 0.3047399520874023
 0.2055919170379639
 0.01958417892456055
 0.09236693382263184
 0.05344319343566895
 0.01389598846435547
 0.01990818977355957
 0.05319404602050781
 0.01967597007751465
 0.009773969650268555
 0.07057690620422363
 0.01362800598144531
 0.02511906623840332
 0.01390600204467773
 1.17902684211731
 0.1035308837890625
 0.1205089092254639
 0.07687282562255859
 1.005826950073242
 0.07081508636474609
 0.07651305198669434
 1.139120101928711
 0.07020092010498047
 0.06988215446472168
 1.053105115890503
 0.02512407302856445
 0.02517414093017578
 1.274722814559937
 0.05312609672546387
 0.03700113296508789
 1.185045003890991
 0.07568717002868652
 0.05895805358886719
 0.05346512794494629
 0.1034121513366699
 0.02090191841125488
 1.196722984313965
 0.06447100639343262
 0.0471489429473877
 0.04241585731506348
 0.01407384872436523
 0.05866694450378418
 0.01390504837036133
 0.1202108860015869
 0.0753939151763916
 0.02063107490539551
 0.07550501823425293
 0
 0.01954793930053711
 0.1593821048736572
 0.01388096809387207
 1.250960111618042
 0.1036350727081299
 0.009243965148925781
 1.051429986953735
 0.1258018016815186
 0.03635621070861816
 1.162370204925537
 0.08103299140930176
 0.09823489189147949
 1.17144513130188
 0.2570111751556396
 0.09235286712646484
 0.01958990097045898
 1.144765853881836
 0.08185887336730957
 0.00826716423034668
 1.497352123260498
 0.01943111419677734
 0.125924825668335
 0.04741096496582031
 0.01389908790588379
 0.06001591682434082
 0.0992579460144043
 0.1884560585021973
 0.009994983673095703
 0.08110904693603516
 0.05864906311035156
 1.167266130447388
 0.09904313087463379
 1.1786789894104
 0.04771900177001953
 0.0925140380859375
 0.06979703903198242
 1.262675046920776
 0.0931088924407959
 1.256900072097778
 0.03079795837402344
 0.02025890350341797
 0.01395201683044434
 1.301242113113403
 0.1651580333709717
 0.165086030960083
 1.143117904663086
 0.08725285530090332
 0.04188394546508789
 0.01945209503173828
 0.09245204925537109
 0.01403903961181641
 1.028132915496826
 0.06434893608093262
 0.03626799583435059
 0.01946592330932617
 1.398342132568359
 0.0585939884185791
 0.04197788238525391
 0.01400399208068848
 0.01839900016784668
 1.107125997543335
 0.04782605171203613
 0.1092510223388672
 1.19529914855957
 0.09226012229919434
 0.09256386756896973
 1.14565896987915
 0.2264900207519531
 0.339900016784668
 0.04250288009643555
 0.1873190402984619
 0.1718981266021729
 0.1380288600921631
 0.109079122543335
 0.05310797691345215
 0.03069710731506348
 0.07012200355529785
 0.07007193565368652
 1.279457092285156
 0.2266409397125244
 0.0925590991973877
 0.10996413230896
 0.09218502044677734
 0.03073811531066895
 0.05865812301635742
 0.1089651584625244
 0.03070783615112305
 0.08671998977661133
 0.09309101104736328
 0.02559900283813477
 1.115846872329712
 0.0809791088104248
 0.6179330348968506
 0.07553386688232422
 0.1261138916015625
 1.752243995666504
 0.1929659843444824
 0.2938878536224365
 0.1314339637756348
 0.1368939876556396
 0.1815760135650635
 0.3159539699554443
 0.3344788551330566
 1.311492919921875
 0.127748966217041
 0.1986010074615479
 0.1429488658905029
 0.01397299766540527
 0.0213780403137207
 0.1091678142547607
 0.01395511627197266
 0.1428830623626709
 0.09272289276123047
 1.401440143585205
 0.05307507514953613
 0.05870199203491211
 0.008359193801879883
 1.015120983123779
 0.08101606369018555
 0.1216750144958496
 0.03670692443847656
 0.1601099967956543
 0.01369500160217285
 1.012707948684692
 0.1386160850524902
 0.1035220623016357
 1.105123996734619
 0.2437169551849365
 0.2601361274719238
 1.17298412322998
 0.3382210731506348
 0.159390926361084
 0.1201629638671875
 0.1650669574737549
 0.04906392097473145
 0.01395010948181152
 1.455284118652344
 0.05302882194519043
 1.133810997009277
 0.1369531154632568
 0.2159290313720703
 0.09909415245056152
 0.1939311027526855
 0.07602787017822266
 0.0602271556854248
 0.109468936920166
 0.04234790802001953
 1.033942222595215
 0.1726958751678467
 0.1315708160400391
 0.3399350643157959
 0.1673309803009033
 0.09910106658935547
 1.25627613067627
 1.355447053909302
 0.1090657711029053
 0.07029008865356445
 0.0430300235748291
 0.03070902824401855
 1.094425916671753
 0.2410640716552734
 1.493630886077881
 0.07546615600585938
 0.0941469669342041
 0.03653717041015625
 1.067290067672729
 0.3979780673980713
 0.165363073348999
 0.07016110420227051
 0.1706838607788086
 0.1650700569152832
 1.268846035003662
 0.3111488819122314
 0.2377891540527344
 0.2603170871734619
 0.1833460330963135
 0.1381080150604248
 0.1778030395507812
 0.2772831916809082
 0.09227895736694336
 0.08654904365539551
 1.347944021224976
 0.06485295295715332
 0.1033799648284912
 0.06428408622741699
 0.02504706382751465
 0.05872893333435059
 1.173516988754272
 0.01369881629943848
 0.06424212455749512
 0.02496981620788574
 0.06982588768005371
 0.01397800445556641
 0.04735398292541504
 0
 0.4986810684204102
 0.1314141750335693
 0.1215898990631104
 0.1097190380096436
 0.07002615928649902
 0.06426000595092773
 0.01386308670043945
 0.09919905662536621
 0.2597529888153076
 0.108903169631958
 0.1391119956970215
 0.1484291553497314
 0.138045072555542
 0.07102513313293457
 0.09230804443359375
 0.1819720268249512
 0.131505012512207
 0.04744887351989746
 1.044358968734741
 0.07017898559570312
 0.1202270984649658
 1.18735408782959
 0.237659215927124
 0.02530193328857422
 0.07578206062316895
 0.1033790111541748
 0.0196840763092041
 0.01395297050476074
 0.05900907516479492
 0.04209518432617188
 0.9720330238342285
 0.07597494125366211
 0.0530550479888916
 0.00381779670715332
 0.269244909286499
 0.3267741203308105
 1.137858867645264
 0.1033110618591309
 0.08193397521972656
 0.01397085189819336
 0.1090531349182129
 0.1043741703033447
 0.03648495674133301
 0.1761558055877686
 0.003950119018554688
 0.1090011596679688
 0.1038100719451904
 0.2829511165618896
 0.0420839786529541
 0.1091248989105225
 0.1765861511230469
 1.158432006835938
 0.1654338836669922
 0.06025600433349609
 0.06433987617492676
 0.110299825668335
 0.01938986778259277
 0.04888391494750977
 0.07525491714477539
 0.04756283760070801
 0.0257720947265625
 0.0705108642578125
 0.0139610767364502
 1.022270917892456
 0.1371078491210938
 0.03068304061889648
 1.044615983963013
 0.1427979469299316
 0.0535130500793457
 0.1425340175628662
 0.2153358459472656
 0.04737091064453125
 1.175015926361084
 0.08739900588989258
 0.03626894950866699
 0.9992139339447021
 0.1986339092254639
 0.2151670455932617
 0.1820220947265625
 0.1257181167602539
 0.08667087554931641
 0.1426730155944824
 0.1264159679412842
 1.07750391960144
 0.02502202987670898
 0.1101388931274414
 0.2710611820220947
 0.2992358207702637
 0
 0.3049299716949463
 0.06994080543518066
 0.0814359188079834
 0.1429250240325928
 1.239479064941406
 1.479117870330811
 0.1261501312255859
 0.08187103271484375
 0.1149599552154541
 1.091080904006958
 0.008486032485961914
 0.1427059173583984
 0.1092889308929443
 1.193735122680664
 0.4557719230651855
 0.1872899532318115
 0.227158784866333
 0.1988050937652588
 0.07581782341003418
 0.1148719787597656
 0.238328218460083
 0.05319881439208984
 0.02029180526733398
 0.1316590309143066
 0.03622293472290039
 0.02507996559143066
 0.1035199165344238
 0.07570505142211914
 1.018836975097656
 0.08659005165100098
 0.02558207511901855
 0.0648491382598877
 0.0536041259765625
 0.1314620971679688
 0.1606600284576416
 0.142582893371582
 0.0425870418548584
 0.04242706298828125
 0.1259400844573975
 0.154120922088623
 0.009181976318359375
 0.07631397247314453
 0.0422980785369873
 0.01404309272766113
 0.06040287017822266
 0.1929531097412109
 1.133795022964478
 0.08701205253601074
 0.0532529354095459
 0.008474111557006836
 0.09351205825805664
 1.333603143692017
 0.03697085380554199
 0.1370458602905273
 0.06978511810302734
 1.061218976974487
 0.1990211009979248
 0.05960297584533691
 1.061615943908691
 0.2824511528015137
 0.3161520957946777
 0.04234504699707031
 0.26021409034729
 0.0868229866027832
 1.073707103729248
 0.3274409770965576
 0.2825281620025635
 0.06440305709838867
 0.1489608287811279
 0.03643393516540527
 0.9793798923492432
 0.1203529834747314
 0.0257871150970459
 0.1541600227355957
 0.1426918506622314
 0.04824709892272949
 1.073309898376465
 0.09799695014953613
 1.235016822814941
 0.1259059906005859
 0.1033799648284912
 0.08657288551330566
 1.065767049789429
 0.04189801216125488
 0.03626704216003418
 1.028532028198242
 0.03066492080688477
 0.01401495933532715
 1.150083065032959
 0.1761281490325928
 0.02546191215515137
 0.03632497787475586
 0.1101088523864746
 0.03066396713256836
 1.071455001831055
 0.1761848926544189
 1.596737146377563
 0.05299901962280273
 0.1771159172058105
 0.04268789291381836
 0.1256780624389648
 0.1381330490112305
 0.1983420848846436
 0.06531095504760742
 0.1663529872894287
 0.09225702285766602
 0.2600381374359131
 0.08670306205749512
 7.988420963287354
 0.2542760372161865
 0.3107569217681885
 4.052414894104004
 0
 0.3888528347015381
 0.1258668899536133
 0.1313498020172119
 0.04762697219848633
 0.02512502670288086
 1.028635025024414
 0.1538560390472412
 0.1816809177398682
 0.9984331130981445
 0.250370979309082
 0.1654930114746094
 0.06458497047424316
 0.1091790199279785
 0.01956391334533691
 1.000137090682983
 0.08688998222351074
 0.02534198760986328
 1.054801940917969
 0.07026100158691406
 0.04744291305541992
 1.195780038833618
 0.03690290451049805
 0.05869603157043457
 1.021865844726562
 0.07014918327331543
 0.05878210067749023
 1.010982990264893
 1.212364912033081
 0
 0.4196200370788574
 0.1597468852996826
 0.109220027923584
 0.04214596748352051
 0.1330230236053467
 0.04744100570678711
 0.171389102935791
 0.0641639232635498
 0.07016491889953613
 0.05330896377563477
 0.1371779441833496
 0.0420069694519043
 1.032847166061401
 0.08668184280395508
 0.06450200080871582
 0.9764461517333984
 0.0377049446105957
 0.04768085479736328
 0.9146919250488281
 1.156662940979004
 0.008686065673828125
 1.015486001968384
 0.1650049686431885
 0.2495341300964355
 0.004346132278442383
 0.08180093765258789
 0.08834099769592285
 0.03642010688781738
 0.07696294784545898
 0.05318808555603027
 1.032660961151123
 0.1496748924255371
 0.1486809253692627
 0.04770302772521973
 0.1105518341064453
 0.05318689346313477
 1.044507026672363
 0.1206271648406982
 0.03666806221008301
 0.01411604881286621
 0.05922198295593262
 1.011213064193726
 0.04740810394287109
 0.1256210803985596
 0.2268610000610352
 1.106295108795166
 0.03645777702331543
 0.2228620052337646
 0.03692293167114258
 0.08154296875
 0.08674716949462891
 0.04760909080505371
 0.1721451282501221
 0.01954293251037598
 0.9942440986633301
 0.1098039150238037
 0.2114741802215576
 0.01949405670166016
 0.09868288040161133
 0.2547879219055176
 0.0474238395690918
 0.1593079566955566
 0.0923759937286377
 1.044553995132446
 0.1480448246002197
 0.09911203384399414
 0.3901331424713135
 0.1320600509643555
 0.08658409118652344
 1.038390159606934
 0.08724188804626465
 1.083648920059204
 1.082589149475098
 0.1479859352111816
 0.37186598777771
 1.028795003890991
 0.05925512313842773
 0.01964187622070312
 0.03721189498901367
 0.3069279193878174
 1.549624919891357
 0.04746818542480469
 0.07688283920288086
 0.1372890472412109
 0.08099603652954102
 0.1480429172515869
 0.1313278675079346
 0.2047469615936279
 0.1649949550628662
 0.4899940490722656
 0.04213905334472656
 0.2600679397583008
 0.1145331859588623
 0.008203029632568359
 0.1593990325927734
 1.234856128692627
 0.01393294334411621
 0.1033070087432861
 0.004302024841308594
 1.168223142623901
 1.495137929916382
 0.1313180923461914
 0.09805989265441895
 0.1760861873626709
 0.1349120140075684
 0.02514290809631348
 0.08137702941894531
 1.151511907577515
 1.204406023025513
 0.1537139415740967
 0.02003598213195801
 0.008327960968017578
 0.1258828639984131
 0.04267311096191406
 0.01384496688842773
 0.00830078125


# name: avgTeste
# type: scalar
0.3139756387074789


# name: antecipatedresponseT
# type: matrix
# rows: 1
# columns: 5
 2 3 2 1 3


