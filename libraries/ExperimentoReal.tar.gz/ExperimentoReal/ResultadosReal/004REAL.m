# Created by Octave 4.2.2, Tue Nov 10 18:24:32 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
004


# name: age
# type: sq_string
# elements: 1
# length: 2
25


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 3 2 6 1 4 5


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 0.8760750293731689
 0.5438590049743652
 0.3500139713287354
 0.3390190601348877
 0.2939660549163818
 0.2942509651184082


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.4495306809743245


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.2938051223754883
 0.2151479721069336
 0.2372720241546631
 0.2705199718475342
 0.2554070949554443
 0.1768741607666016
 0.1986339092254639
 0.1607730388641357
 0.1600079536437988
 0.2819490432739258
 0.2983260154724121
 0.137300968170166
 0.1982169151306152
 0.1924359798431396
 0.1535511016845703
 0.2929558753967285
 0.08130502700805664
 0.2034380435943604
 0.1647520065307617
 0.2450551986694336
 0.1035640239715576
 0.2273797988891602
 0.3605968952178955
 0.2287740707397461
 0.3095839023590088
 0.1980109214782715
 0.3047139644622803
 0.3155169486999512
 0.1422951221466064
 0.1274139881134033
 0.1812899112701416
 0.09214115142822266
 0.181380033493042
 0.2325088977813721
 0.3832612037658691
 0.1929030418395996
 0.1760759353637695
 0.1926188468933105
 0.1370539665222168
 0.332974910736084
 0.1980669498443604
 0.2100038528442383
 0.2539329528808594
 0.1260781288146973
 0.1532950401306152
 0.1200330257415771
 0.06415510177612305
 0.03709983825683594
 0.1603860855102539
 0.05315899848937988
 0.153796911239624
 0.2150309085845947
 0.13680100440979
 0.1201460361480713
 0.3438520431518555
 0.1031930446624756
 0.1038670539855957
 0.1813411712646484
 1.060123920440674
 0.4156861305236816
 0.3935990333557129
 0.2203860282897949
 0.1264140605926514
 0.3220407962799072
 0.1039688587188721
 0.2147111892700195
 0.136584997177124
 0.2154748439788818
 0.09767293930053711
 0.1924738883972168
 0.06488800048828125
 0.1711931228637695
 0.1543710231781006
 0.1647961139678955
 0.0140068531036377
 0.09391689300537109
 0.08769392967224121
 0.07642889022827148
 0.1657519340515137
 0.05887985229492188
 0.1711211204528809
 0.254755973815918
 0.365772008895874
 0.1283659934997559
 0.1314010620117188
 0.1095371246337891
 0.1258780956268311
 0.1985499858856201
 0.03076386451721191
 0.1428298950195312
 0.214893102645874
 0.2598848342895508
 0.2722599506378174
 0.1255950927734375
 0.1985950469970703
 0.125762939453125
 0.0701601505279541
 0.2273058891296387
 0.1370558738708496
 0.1707980632781982
 0.05390000343322754
 0.05857396125793457
 0.1984989643096924
 0.0200340747833252
 0.1270701885223389
 0.1193878650665283
 0.3320550918579102
 0.07552599906921387
 0.1253650188446045
 0.1311728954315186
 0.3938648700714111
 0.2036449909210205
 0.03084802627563477
 0.01998400688171387
 0.1714529991149902
 0.03134799003601074
 0.01400113105773926
 0.02498221397399902
 0.03748106956481934
 0.2372970581054688
 0.3260648250579834
 0.2146708965301514
 0.2815570831298828
 0.08653712272644043
 0.1760308742523193
 0.07659196853637695
 0.07646894454956055
 0.0544440746307373
 0.04748702049255371
 0.04753613471984863
 0.03702116012573242
 0.03721213340759277
 0.1816339492797852
 0.01970720291137695
 0.05453610420227051
 0.04751682281494141
 2.124964952468872
 1.657189130783081
 0.1377348899841309
 0.3164358139038086
 0.2542428970336914
 0.2099740505218506
 0.4829261302947998
 0.1653511524200439
 0.326901912689209
 0.1254589557647705
 0.3325300216674805
 0.2547659873962402
 0.05309104919433594
 0.1591131687164307
 0.7678399085998535
 0.1315209865570068
 0.1540741920471191
 0.1648390293121338
 0.02646899223327637
 1.661012172698975
 0.1539959907531738
 0.149385929107666
 0.09204816818237305
 0.1032159328460693
 0.0474400520324707
 1.366769075393677
 0.1918430328369141
 0.07548213005065918
 0.03646421432495117
 0.06960415840148926
 0.03206014633178711
 1.25819206237793
 0.3262498378753662
 0.1150548458099365
 0.05317091941833496
 0.0597691535949707
 0.06411099433898926
 1.252174854278564
 0.131939172744751
 0.03052592277526855
 1.514427900314331
 0.3989870548248291
 0.1257059574127197
 1.537659883499146
 0.248399019241333
 0.09300684928894043
 0.03079009056091309
 0.06424307823181152
 0.1318471431732178
 1.55191707611084
 0.44392991065979
 0.14274001121521
 0
 1.738509893417358
 0.2209680080413818
 0.3996531963348389
 0.1258420944213867
 0.1312649250030518
 0.1273078918457031
 0.1755828857421875
 0.1030819416046143
 1.058905124664307
 0.2927219867706299
 0.1868669986724854
 1.281148910522461
 0.2603552341461182
 0.3551831245422363
 0.2253260612487793
 0.2536149024963379
 0.142193078994751
 0.08101105690002441
 0.1588790416717529
 0.3598380088806152
 0.1365649700164795
 0.1086881160736084
 0.0641632080078125
 0.01387906074523926
 0.1658949851989746
 1.196096181869507
 0.04728603363037109
 0.1324889659881592
 0.06404805183410645
 0.008359193801879883
 0.08171510696411133
 0.2720620632171631
 0.1485400199890137
 0.2426249980926514
 0.1365070343017578
 0.008286952972412109
 0.2373011112213135
 0.008391857147216797
 1.319441795349121
 0.1923930644989014
 1.533867835998535
 0.1370100975036621
 0.1478638648986816
 0.04176807403564453
 0.9426219463348389
 0.3894619941711426
 0.3995299339294434
 0.1995558738708496
 0.05952596664428711
 0.1426329612731934
 0.06084489822387695
 0.07027697563171387
 1.221896886825562
 0.08729791641235352
 0.1093440055847168
 0.1200108528137207
 0.01484298706054688
 0.05928492546081543
 1.857338905334473
 0.06387019157409668
 0.1326589584350586
 1.360282897949219
 0.4442579746246338
 1.084566116333008
 0.3662259578704834
 0.3163518905639648
 0.1645560264587402
 0.1145219802856445
 1.528294801712036
 0.1088910102844238
 0.1367690563201904
 0.08087992668151855
 0.04740285873413086
 0.08648419380187988
 1.266174077987671
 0.1199591159820557
 0.09778380393981934
 0.3287591934204102
 0.05852198600769043
 0.0486299991607666
 1.110182046890259
 0.05919289588928223
 0.13661789894104
 0.04172301292419434
 0.1093990802764893
 1.108875036239624
 0.6971848011016846
 0.3716058731079102
 0.07698202133178711
 0.1551158428192139
 0.165233850479126
 0.03064489364624023
 0.2603719234466553
 0.07000279426574707
 1.412723779678345
 0.1874890327453613
 0.09205794334411621
 0.0537409782409668
 0.04186511039733887
 0.01966691017150879
 0.0809481143951416
 0.01490998268127441
 0.5385839939117432
 0.01519203186035156
 1.965472221374512
 0.3432629108428955
 0.1662540435791016
 0.2424230575561523
 0.3819899559020996
 0.3156280517578125
 0.1365489959716797
 0.4003589153289795
 0.08113789558410645
 0.1481678485870361
 0.159196138381958
 0.01397299766540527
 0.07025289535522461
 0.1983168125152588
 0.3021299839019775
 0.3149869441986084
 0.1644048690795898
 0.04159307479858398
 0.192918062210083
 0.06978487968444824
 0.02498102188110352
 0.02511811256408691
 0.08191680908203125
 1.095832824707031
 0.2312428951263428
 0.05312204360961914
 0.03174686431884766
 0.01455187797546387
 0.01384496688842773
 1.202720880508423
 0.04172897338867188
 0.06009387969970703
 0.2163078784942627
 0.02509784698486328
 0.06968784332275391
 0.0191349983215332
 0.02489686012268066
 0.08112907409667969
 0.1424601078033447
 1.081707954406738
 0.2491190433502197
 0.03065705299377441
 0.6281421184539795
 0.2276990413665771
 0.1648721694946289
 0.0931861400604248
 0.1757400035858154
 0.04731583595275879
 0.1365921497344971
 0.08651590347290039
 0.04789209365844727
 0.175908088684082
 0.0432431697845459
 0.04213714599609375
 0.4963598251342773
 0.232982873916626
 0.1814610958099365
 0.1980149745941162
 0.3821661472320557
 0.008335113525390625
 0.1755340099334717
 0.03053593635559082
 0.01423311233520508
 0.05331110954284668
 1.052477836608887
 1.352514028549194
 0.2146618366241455
 0.1541659832000732
 0.0305020809173584
 0.103132963180542
 0.03620696067810059
 1.318818092346191
 0.164762020111084
 0.06968593597412109
 1.106908082962036
 0.4909300804138184
 0.4844970703125
 0.2482140064239502
 0.1925601959228516
 0.03598713874816895
 0.04736495018005371
 1.280389070510864
 0.09190797805786133
 0.08640599250793457
 0.1923820972442627
 0.08628606796264648
 0.01377010345458984
 0.01997613906860352
 0.3429591655731201
 0.1491110324859619
 0.108734130859375
 0.1365678310394287
 0.2046291828155518
 0.125356912612915
 0.03065800666809082
 0.2202000617980957
 0.05337786674499512
 0.03613710403442383
 0.07638287544250488
 0.03113484382629395
 0.01382708549499512
 0.0138239860534668
 0.03174901008605957
 0.05333900451660156
 0.9649720191955566
 0.9543139934539795
 0.08054590225219727
 1.046043157577515
 0.1821048259735107
 0.337270975112915
 0.2311921119689941
 0.1657078266143799
 0.0808110237121582
 0.05315494537353516
 0.08084702491760254
 0.0305321216583252
 0.08784103393554688
 0.4714100360870361
 0.1755070686340332
 0.09788799285888672
 0.1253459453582764
 0.5381119251251221
 0.1980628967285156
 0.1477930545806885
 0.06026601791381836
 1.197727918624878
 0.254518985748291
 0.01966595649719238
 0.04755187034606934
 0.1705901622772217
 0.08261513710021973
 1.143699169158936
 0.1434841156005859
 0.01365518569946289
 1.186305046081543
 0.05508089065551758
 0.1924200057983398
 1.103338956832886
 0.3374159336090088
 0.1030118465423584
 0.2092921733856201
 0.08668708801269531
 0.0305168628692627
 0.0139310359954834
 0.2069318294525146
 0.2984421253204346
 0.1595759391784668
 0.1700730323791504
 0.103269100189209
 2.235201835632324
 0.1308748722076416
 0.09757804870605469
 0.1875817775726318
 0.1424460411071777
 0.03664898872375488
 0.04158997535705566
 0.1095378398895264
 0.1982779502868652
 0.008512973785400391
 0.07600784301757812
 0.1426658630371094
 1.194849014282227
 0.2320420742034912
 0.05866503715515137
 0.01404213905334473
 0.1037919521331787
 0.03762316703796387
 1.535589933395386
 0.1366028785705566
 0.2480618953704834
 0.02016091346740723
 0.03103303909301758
 1.279914140701294
 0.1147871017456055
 0.08103609085083008
 0.009866952896118164
 0.08656787872314453
 0.0696721076965332
 0.008980989456176758
 0.09751701354980469
 0.07522392272949219
 0.03098106384277344
 1.107226133346558
 0.04756903648376465
 0.0257880687713623
 1.142974853515625
 0.2990231513977051
 0.3723869323730469
 0.1201190948486328
 0.5197288990020752
 0.1657450199127197
 0.1589550971984863
 0.3048150539398193
 0.05289196968078613
 0.09307217597961426
 0.103179931640625
 0.1925280094146729
 0.126190185546875
 0.04782795906066895
 1.069345951080322
 1.215814828872681
 0.3873391151428223
 0.4761598110198975
 0.3271698951721191
 0.04745697975158691
 0.1310079097747803
 0.01510000228881836
 0.03249382972717285
 0.03612303733825684
 0.03620100021362305
 0.05320000648498535
 1.093307971954346
 0.1256778240203857
 0.171205997467041
 0.09321403503417969
 0.06965494155883789
 0.1032969951629639
 0.1086990833282471
 0.2202689647674561
 0.1763560771942139
 0.03632783889770508
 1.881043910980225
 0.1143879890441895
 0.108698844909668
 0.03712010383605957
 0.02006697654724121
 0.01970887184143066
 1.571058988571167
 0.0923159122467041
 0.01404380798339844
 0.1033618450164795
 0.09793186187744141
 0.06401586532592773
 0.02626395225524902
 1.277026891708374
 0.05294203758239746
 1.168806076049805
 0.1894021034240723
 0.2544889450073242
 0.01959609985351562
 0.1258080005645752
 0.03633594512939453
 0.03631711006164551
 0.1089539527893066
 0.1817469596862793
 0.04742193222045898
 0.1430461406707764
 0.04758191108703613
 0.04750299453735352
 0.1031241416931152
 0.08195185661315918
 0.0701138973236084
 0.119520902633667
 0.2051098346710205
 0.0473179817199707
 0.03060197830200195
 0.08077597618103027
 1.07944393157959
 0.3820228576660156
 0.1644830703735352
 0.0706031322479248
 0.147784948348999
 0.2090928554534912
 0.1036579608917236
 0.3628339767456055
 0.1775820255279541
 0.06402897834777832
 0.2259948253631592
 1.04259991645813
 0.08692097663879395
 0.05637693405151367
 0.02035903930664062
 1.159548997879028
 0.103477954864502
 0.08684492111206055
 0.8627078533172607
 0.01949501037597656
 0.09189605712890625
 0.2429540157318115
 0.1368808746337891
 0.1534280776977539
 0.08080792427062988
 0.1199002265930176
 0.148967981338501
 0.07572484016418457
 0.1033639907836914
 0.06973600387573242
 1.03653883934021
 0.03064703941345215
 0.09755301475524902
 1.147826194763184
 0.06072187423706055
 0.1760561466217041
 0.07534503936767578
 0.2147500514984131
 0.1086289882659912
 0.03667688369750977
 0.2603371143341064
 0.07018494606018066
 0.04190206527709961
 0.06471896171569824
 0.06977391242980957
 0.1559348106384277
 0.1430931091308594
 0.01965522766113281
 1.091788053512573
 0.288646936416626
 0.1715919971466064
 0.01433086395263672
 0.08109712600708008
 0.1554281711578369
 0.05300092697143555
 0.119830846786499
 0.187114953994751
 0.1661460399627686
 0.1434531211853027
 0.09197497367858887
 0.1423249244689941
 0.06962895393371582
 0.1867868900299072
 0.270287036895752
 0.1421329975128174
 0.1984889507293701
 0.09772920608520508
 0.1759510040283203
 0.1652519702911377
 0.09219813346862793
 0.2875270843505859
 0.1872661113739014
 0.1887810230255127
 0.1438899040222168
 0.1218311786651611
 0.1815230846405029
 0.1254978179931641
 0.1765599250793457
 0.09292197227478027
 0.1312119960784912
 0.1552298069000244
 0.01503086090087891
 0.1311941146850586
 0.07537102699279785
 0.1480419635772705
 0.119966983795166
 0.08664917945861816
 0.09776496887207031
 0.1435058116912842
 0.07553696632385254
 0.1944980621337891
 0.115786075592041
 0.1654059886932373
 0.1818299293518066
 0.1276051998138428
 0.1550509929656982
 0.06985306739807129
 0.06983399391174316
 0.2038850784301758
 0.09782910346984863
 0.1203091144561768
 0.1425521373748779
 0.2151029109954834
 0.08103609085083008
 0.204207181930542
 0.08676815032958984
 0.1594030857086182
 0.1540708541870117
 0.09792709350585938
 0.154109001159668
 0.2766990661621094
 0.09252285957336426
 0.127234935760498
 0.10447096824646
 0.1653060913085938
 0.2374358177185059
 0.3903379440307617
 0.1484019756317139
 0.1479918956756592
 0.03636503219604492
 0.1423439979553223
 0.1593878269195557
 0.1612420082092285
 0.1147341728210449
 0.1146578788757324
 0.0978240966796875
 0.1313731670379639
 0.1089050769805908
 0.6373691558837891
 0.2441880702972412
 0.1709349155426025
 0.09810304641723633
 0.04192399978637695
 0.1599490642547607
 0.06406712532043457
 0.09218788146972656
 0.04747700691223145
 0.03632593154907227
 0.1367499828338623
 0.1871891021728516
 0.1369659900665283
 0.1089560985565186
 0.05309009552001953
 0.1871812343597412
 0.1260440349578857
 0.2870268821716309
 0.15907883644104
 0.1927831172943115
 0.1599140167236328
 0.1759798526763916
 0.1035909652709961
 0.1648480892181396
 0.1426370143890381
 0.120434045791626
 0.1494810581207275
 0.2102899551391602
 0.05980706214904785
 0.1325809955596924
 0.0754551887512207
 0.1424269676208496
 0.09346485137939453
 0.1146159172058105
 0.1316328048706055
 0.1254470348358154
 0.1031770706176758
 0.126068115234375
 0.2661490440368652
 0.06923580169677734
 1.501214981079102
 0.1813468933105469
 0.09237384796142578
 0.1090788841247559
 0.1873829364776611
 0.109367847442627
 0.07688498497009277
 0.07230901718139648
 0.08636593818664551
 0.1266670227050781
 0.07560920715332031
 0.04249405860900879
 0.2094230651855469
 0.04759311676025391
 0.131166934967041
 0.09787988662719727
 0.07008194923400879
 0.1033129692077637
 0.1315691471099854
 0.08788800239562988
 0.04273200035095215
 0.03636908531188965
 0.05967879295349121
 0.05852699279785156
 0.1031179428100586
 0.1031830310821533
 0.08657097816467285
 0.05966997146606445
 0.2376210689544678
 0.09238314628601074
 0.07070803642272949
 0.2540209293365479


# name: avgTeste
# type: scalar
0.240691509882609


# name: antecipatedresponseT
# type: scalar
2


