# Created by Octave 4.2.2, Wed Dec 02 11:11:35 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
007


# name: age
# type: sq_string
# elements: 1
# length: 2
30


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 3 2 5 6 4 1


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 0.4037950038909912
 0.3780219554901123
 0.2681581974029541
 0.2771360874176025
 0.4175381660461426
 0.3385040760040283


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.3471922477086385


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.3053231239318848
 0.2997729778289795
 0.3784279823303223
 0.3330209255218506
 0.2715010643005371
 0.3107969760894775
 0.3558690547943115
 0.3617908954620361
 0.4284820556640625
 0.2771680355072021
 0.238123893737793
 0.1821079254150391
 0.160149097442627
 0.2601079940795898
 0.2387099266052246
 0.1873278617858887
 0.1822190284729004
 0.2828269004821777
 0.2658088207244873
 0.444828987121582
 0.3899588584899902
 0.3778510093688965
 0.2714040279388428
 0.2884440422058105
 0.2564859390258789
 0.2883620262145996
 0.2549068927764893
 0.2058911323547363
 0.2607040405273438
 0.2937431335449219
 0.2728359699249268
 0.2328519821166992
 0.2213559150695801
 0.2607681751251221
 0.3106939792633057
 0.289949893951416
 0.2043747901916504
 0.2159669399261475
 0.2830209732055664
 0.2270491123199463
 0.38319993019104
 0.4895839691162109
 0.3451559543609619
 0.221625804901123
 0.2379031181335449
 0.27134108543396
 0.2656760215759277
 0.2153232097625732
 0.2211458683013916
 0.1315851211547852
 0.05321598052978516
 0.4051470756530762
 0.2263720035552979
 0.4848048686981201
 0.2715418338775635
 0.3280668258666992
 0.2713091373443604
 0.244502067565918
 0.2104551792144775
 0.1374101638793945
 0.3409180641174316
 0.2344121932983398
 0.2545790672302246
 0.2543680667877197
 0.1986680030822754
 0.08715605735778809
 0.2152378559112549
 0.114689826965332
 0.2894630432128906
 0.09232401847839355
 0.1604249477386475
 0.216170072555542
 0.2999069690704346
 0.1986930370330811
 0.2895269393920898
 0.2660079002380371
 0.2212870121002197
 0.04761195182800293
 0.2997620105743408
 0.2380518913269043
 0.2435019016265869
 0.1944470405578613
 0.2549171447753906
 0.2506730556488037
 0.2108519077301025
 0.1432230472564697
 0.1490261554718018
 0.05357599258422852
 5.428921937942505
 1.251868963241577
 0.4453599452972412
 0.4784140586853027
 0.278458833694458
 0.4518818855285645
 0.2775712013244629
 0.204110860824585
 0.1761391162872314
 0.3552100658416748
 0.2598741054534912
 0.1706409454345703
 0.1881129741668701
 0.2325890064239502
 0.1762731075286865
 0.2043421268463135
 0.2664930820465088
 0.2101199626922607
 0.2492239475250244
 0.2605059146881104
 0.2439289093017578
 0.4121010303497314
 0.2774767875671387
 0.2732009887695312
 0.293816089630127
 0.4297139644622803
 0.4505288600921631
 0.2158911228179932
 0.2435498237609863
 0.1773619651794434
 0.2716019153594971
 0.2670111656188965
 0.1706569194793701
 0.2322878837585449
 0.1761949062347412
 0.1985340118408203
 0.2766849994659424
 0.3327798843383789
 0.1374030113220215
 0.008379936218261719
 0.2657010555267334
 0.05881786346435547
 0.02646994590759277
 2.47990894317627
 0.3396091461181641
 0.2993271350860596
 0.2214391231536865
 0.2265388965606689
 0.2040379047393799
 0.2374148368835449
 0.1651749610900879
 0.3606619834899902
 0.2711310386657715
 0.1313371658325195
 0.115900993347168
 0.1325681209564209
 0.4417438507080078
 0.1427040100097656
 0.3010809421539307
 0.2278409004211426
 0.2104310989379883
 0.06592988967895508
 0.6012780666351318
 0.2547628879547119
 0.1989731788635254
 0.1817460060119629
 0.1089870929718018
 0.2544121742248535
 0.2066240310668945
 0.2377920150756836
 0.103550910949707
 0.2331581115722656
 0.1598289012908936
 0.1040480136871338
 0.1815779209136963
 0.1546850204467773
 0.1503198146820068
 0.1654691696166992
 0.166273832321167
 0.08784604072570801
 0.3047299385070801
 0.1313571929931641
 0.215735912322998
 0.1540911197662354
 0.09912490844726562
 0.08092713356018066
 0.2710158824920654
 0.3103549480438232
 0.2830049991607666
 0.3159492015838623
 0.2319831848144531
 0.03225088119506836
 0.2212331295013428
 0.1262211799621582
 4.363613843917847
 0.3326280117034912
 0.3665080070495605
 0.176520824432373
 0.2546310424804688
 0.2827510833740234
 0.2208330631256104
 0.1932880878448486
 0.1888799667358398
 0.1424520015716553
 0.2152771949768066
 0.1820499897003174
 0.08674407005310059
 0.2206430435180664
 0.04243612289428711
 0.06980299949645996
 0.1815972328186035
 1.680295944213867
 0.1099660396575928
 0.2663040161132812
 0.1927790641784668
 0.3217310905456543
 0.237591028213501
 0.2544980049133301
 0.2546579837799072
 0.1200590133666992
 0.1091690063476562
 0.1040921211242676
 0.1501801013946533
 0.1487329006195068
 0.1559290885925293
 0.04904294013977051
 0.115847110748291
 0.2548291683197021
 0.1314799785614014
 0.04312610626220703
 0.310297966003418
 0.1592528820037842
 0.1877040863037109
 0.09439277648925781
 0.08846092224121094
 0.148496150970459
 0.110374927520752
 0.2335810661315918
 0.283257007598877
 0.008461952209472656
 0.04872703552246094
 0.05310297012329102
 0.1824917793273926
 0.2337789535522461
 0.2174630165100098
 0.254655122756958
 0.1874630451202393
 0.1483018398284912
 0.09777593612670898
 0.2606298923492432
 0.2107570171356201
 0.3838648796081543
 0.1709890365600586
 0.2778630256652832
 0.2221188545227051
 0.07556700706481934
 0.2942559719085693
 0.2057890892028809
 0.1876649856567383
 0.1543409824371338
 0.08723711967468262
 0.165215015411377
 0.1314718723297119
 0.3554050922393799
 0.2998530864715576
 0.2615480422973633
 0.5238080024719238
 0.293881893157959
 0.2107670307159424
 0.5577318668365479
 0.6688089370727539
 0.1880059242248535
 0.1941940784454346
 0.3556540012359619
 0.1485400199890137
 0.1211938858032227
 0.1711061000823975
 0.07582807540893555
 0.07646608352661133
 0.1543710231781006
 1.699958801269531
 0.300684928894043
 0.8920741081237793
 0.2381999492645264
 0.2613539695739746
 0.3726820945739746
 0.2326009273529053
 0.4166140556335449
 0.2491641044616699
 0.4673171043395996
 0.3172519207000732
 0.1153991222381592
 0.2601211071014404
 0.1718599796295166
 0.164808988571167
 0.0868070125579834
 0.3497059345245361
 0.4067270755767822
 0.1482169628143311
 0.4002928733825684
 0.2654318809509277
 0.3053789138793945
 0.3279321193695068
 0.20436692237854
 0.3069548606872559
 0.3014981746673584
 0.3388998508453369
 0.2621879577636719
 0.237746000289917
 0.1478359699249268
 0.1094570159912109
 0.06432986259460449
 0.5652079582214355
 0.2211589813232422
 0.2048060894012451
 0.2105491161346436
 0.2712860107421875
 0.1596741676330566
 0.3327620029449463
 0.1393649578094482
 0.3106839656829834
 0.1721022129058838
 0.4843740463256836
 0.2155241966247559
 0.2378969192504883
 0.277224063873291
 0.2557380199432373
 0.3108808994293213
 0.2213180065155029
 0.04762387275695801
 0.2883579730987549
 0.2884149551391602
 0.2441911697387695
 0.4799609184265137
 0.2937932014465332
 0.327186107635498
 0.3719899654388428
 0.2605998516082764
 0.4053559303283691
 0.3949441909790039
 0.4244310855865479
 0.4230048656463623
 0.417248010635376
 0.5567500591278076
 0.390125036239624
 0.5065720081329346
 0.2605950832366943
 0.2681369781494141
 0.8333981037139893
 0.4732210636138916
 0.344304084777832
 0.283034086227417
 0.2937979698181152
 0.2546019554138184
 0.355327844619751
 0.2937538623809814
 0.2660729885101318
 0.2443859577178955
 0.2884538173675537
 0.1819119453430176
 0.6984670162200928
 0.3664867877960205
 0.6310040950775146
 0.333266019821167
 0.2548000812530518
 0.2949161529541016
 0.2942638397216797
 0.2435848712921143
 0.2154858112335205
 0.3009719848632812
 0.254706859588623
 0.1091020107269287
 0.3163108825683594
 0.2213301658630371
 0.206057071685791
 0.2888798713684082
 0.4619979858398438
 0.2830550670623779
 0.2382810115814209
 0.1595339775085449
 0.383167028427124
 0.4948420524597168
 0.3666560649871826
 0.4280469417572021
 0.4843010902404785
 0.4452998638153076
 0.3332188129425049
 0.4509599208831787
 0.389258861541748
 0.2998130321502686
 0.283538818359375
 0.176353931427002
 1.06702709197998
 0.2779719829559326
 0.4004321098327637
 0.4223489761352539
 0.2731978893280029
 0.2493619918823242
 0.3998301029205322
 0.3450160026550293
 0.2378089427947998
 0.232356071472168
 0.2608778476715088
 0.2488110065460205
 0.192983865737915
 0.3777029514312744
 0.3283040523529053
 0.2604730129241943
 0.2605810165405273
 0.2548720836639404
 0.2849180698394775
 0.2713251113891602
 0.2207479476928711
 0.1648409366607666
 0.4278061389923096
 0.3796300888061523
 0.1537449359893799
 0.3561899662017822
 0.2505178451538086
 0.2216379642486572
 0.2101438045501709
 0.2439861297607422
 0.3225538730621338
 0.2111430168151855
 0.6860189437866211
 0.2607779502868652
 0.429563045501709
 0.3103179931640625
 0.3270537853240967
 0.4905061721801758
 0.1987481117248535
 0.5580658912658691
 0.3441801071166992
 0.1480171680450439
 0.3892099857330322
 0.2827920913696289
 0.1157569885253906
 0.2055790424346924
 0.1932580471038818
 0.356220006942749
 0.3667659759521484
 0.1649150848388672
 0.3887588977813721
 0.2156450748443604
 0.2208437919616699
 0.237483024597168
 0.2098028659820557
 0.2670450210571289
 0.283146858215332
 0.2882339954376221
 0.2232129573822021
 0.2439839839935303
 0.3226180076599121
 0.2715508937835693
 0.1711690425872803
 0.181859016418457
 0.323660135269165
 0.2939510345458984
 0.2939629554748535
 0.4964110851287842
 0.3506238460540771
 0.2152040004730225
 0.4232280254364014
 0.3720180988311768
 0.2901639938354492
 0.2897920608520508
 0.4514877796173096
 0.3673739433288574
 0.2908201217651367
 0.2323310375213623
 0.1259419918060303
 0.1762480735778809
 0.2154169082641602
 0.05993080139160156
 0.3159110546112061
 0.2771217823028564
 0.1839861869812012
 0.1598501205444336
 0.243973970413208
 0.2281880378723145
 0.2603201866149902
 0.1876919269561768
 0.2158479690551758
 0.2102260589599609
 0.1935641765594482
 0.2040441036224365
 0.29376220703125
 0.2283320426940918
 0.2936959266662598
 0.2546939849853516
 0.1089799404144287
 0.1816389560699463
 0.1657078266143799
 0.1597118377685547
 0.1089401245117188
 0.0660550594329834
 2.064659833908081
 0.3226449489593506
 0.8757860660552979
 0.3737568855285645
 0.2326641082763672
 0.5723390579223633
 0.2944259643554688
 0.3110551834106445
 0.3501219749450684
 0.2881920337677002
 0.374330997467041
 0.3400750160217285
 0.3895809650421143
 0.3841221332550049
 0.3403739929199219
 0.3665540218353271
 0.4053471088409424
 0.82611083984375
 0.4110932350158691
 0.3834681510925293
 0.3105459213256836
 0.2209420204162598
 0.2489180564880371
 0.1649141311645508
 0.1091079711914062
 0.02504301071166992
 0.3173069953918457
 0.2431240081787109
 0.2780590057373047
 0.2601208686828613
 0.1148848533630371
 0.7074201107025146
 0.2601919174194336
 0.2221598625183105
 0.3721840381622314
 0.32269287109375
 0.2334761619567871
 0.2717020511627197
 0.2607390880584717
 0.3233120441436768
 0.20607590675354
 0.1706521511077881
 0.08265399932861328
 0.1258008480072021
 0.3610298633575439
 0.2942929267883301
 0.2712299823760986
 0.2880790233612061
 0.1482250690460205
 0.4069409370422363
 0.2543289661407471
 0.2725358009338379
 0.2653040885925293
 0.2377538681030273
 0.355597972869873
 0.1994709968566895
 0.2039320468902588
 0.3226611614227295
 1.559707880020142
 2.35838794708252
 0.5010600090026855
 0.265855073928833
 0.2189841270446777
 0.3952999114990234
 0.5515930652618408
 0.1765651702880859
 0.2381069660186768
 0.1886429786682129
 0.3779430389404297
 0.1986360549926758
 0.1258640289306641
 0.4677281379699707
 0.2828230857849121
 0.2212839126586914
 0.1163041591644287
 0.1987550258636475
 0.2214031219482422
 0.2899458408355713
 0.1595849990844727
 0.4953510761260986
 0.2212021350860596
 0.02590703964233398
 0.2171008586883545
 0.1875541210174561
 0.0822141170501709
 2.30259108543396
 0.388962984085083
 0.4393908977508545
 0.3789279460906982
 0.3106110095977783
 0.3837361335754395
 0.2273180484771729
 0.3100450038909912
 0.2602808475494385
 0.3444550037384033
 0.2156109809875488
 0.1151330471038818
 0.2600901126861572
 0.2921698093414307
 0.2770059108734131
 0.1258080005645752
 0.4054350852966309
 0.08106279373168945
 0.3727419376373291
 0.2660691738128662
 0.2994620800018311
 0.2671298980712891
 0.3341019153594971
 0.2897098064422607
 0.1824951171875
 0.6744859218597412
 0.2266111373901367
 0.7187900543212891
 0.3070781230926514
 0.137598991394043
 0.2444350719451904
 0.417151927947998
 0.2824709415435791
 0.226550817489624
 0.2376148700714111
 0.2212538719177246
 0.3051228523254395
 0.2394278049468994
 0.2608819007873535
 0.2453367710113525
 0.2108078002929688
 0.2053909301757812
 0.0928199291229248
 0.1225159168243408
 0.1823818683624268
 0.06998300552368164
 0.2210900783538818
 0.1773498058319092
 0.1658010482788086
 0.09259891510009766
 0.1550698280334473
 0.6191518306732178
 0.1326661109924316
 0.2605128288269043
 0.1987371444702148
 0.1149649620056152
 0.249392032623291
 0.1765589714050293
 0.2436120510101318
 0.226801872253418
 0.2267110347747803
 0.2900378704071045
 0.2602930068969727
 0.1539061069488525
 0.1930711269378662
 0.4282951354980469
 0.2771830558776855
 0.06995701789855957
 0.2680289745330811
 0.1826920509338379
 0.2334120273590088
 0.06460094451904297
 0.3280749320983887
 0.2442049980163574
 0.2216219902038574
 0.8959519863128662
 0.3109931945800781
 0.1988189220428467
 0.2102470397949219
 0.2743699550628662
 0.2711460590362549
 0.2729699611663818
 0.2766830921173096
 0.1878671646118164
 0.1100690364837646
 0.08655595779418945
 0.2552640438079834
 0.2666118144989014
 0.1927080154418945
 0.1326220035552979
 0.25531005859375
 0.2380070686340332
 0.2913908958435059
 0.2887990474700928
 0.1770689487457275
 0.1983418464660645
 0.04748415946960449
 0.534060001373291
 0.243211030960083
 0.2881419658660889
 0.1887750625610352
 0.2571408748626709
 0.2549340724945068
 0.2497308254241943
 0.2835612297058105
 0.3121559619903564
 0.3214709758758545
 0.1424949169158936
 0.2672369480133057
 0.07551002502441406
 0.07034611701965332
 0.07030105590820312
 0.1434159278869629
 1.673079967498779
 0.354870080947876
 0.4517130851745605
 0.6966369152069092
 0.7861180305480957
 0.2212660312652588
 0.1485140323638916
 0.1549859046936035
 0.6814141273498535
 0.3107509613037109
 0.2604999542236328
 0.2545211315155029
 0.1989660263061523
 0.6178438663482666
 0.215947151184082
 0.2328300476074219
 0.2772800922393799
 0.2720987796783447
 0.1942110061645508
 0.2488489151000977
 0.2711400985717773
 0.2598409652709961
 0.4796509742736816
 0.3327059745788574
 0.04739809036254883
 0.7517271041870117
 0.4055690765380859
 0.3945951461791992
 0.3102860450744629
 0.2040600776672363
 0.2544748783111572
 0.1424510478973389
 0.3324968814849854
 0.4782328605651855
 0.898446798324585
 0.2655599117279053
 0.2543230056762695
 0.155426025390625
 0.1960148811340332
 0.2110419273376465
 0.1877510547637939
 0.1047048568725586
 0.07003688812255859
 0.2704660892486572
 0.2941601276397705
 0.1990289688110352
 0.2275509834289551
 0.1882400512695312
 0.2154989242553711
 0.1943762302398682
 0.1158931255340576
 0.2050671577453613
 0.1760649681091309
 0.2597169876098633
 0.2319021224975586
 0.1710031032562256
 0.05920100212097168
 0.1103098392486572
 0.02516698837280273
 0.0362091064453125
 0.01951408386230469
 0.03078484535217285
 0.08123898506164551
 1.620033979415894
 0.3778619766235352
 0.3555850982666016
 0.2213230133056641
 0.2216339111328125


# name: avgTeste
# type: scalar
0.2960750970840454


# name: antecipatedresponseT
# type: matrix
# rows: 0
# columns: 0


