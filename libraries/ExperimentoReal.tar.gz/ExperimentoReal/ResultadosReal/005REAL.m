# Created by Octave 4.2.2, Thu Nov 26 10:11:35 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
005


# name: age
# type: sq_string
# elements: 1
# length: 2
32


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 4 3 6 2 5 1


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 2.497433185577393
 2.04449200630188
 0.3569998741149902
 0.2708570957183838
 0.3493931293487549
 0.2765657901763916


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.9659568468729655


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.2891290187835693
 0.2387130260467529
 0.2385220527648926
 0.3766071796417236
 0.2649037837982178
 0.2879960536956787
 0.1942989826202393
 0.1647789478302002
 0.1836488246917725
 0.1646468639373779
 0.1536421775817871
 0.08668017387390137
 0.1540229320526123
 0.1152548789978027
 0.08086204528808594
 0.1870160102844238
 0.1981990337371826
 0.2213640213012695
 0.1925549507141113
 0.1425020694732666
 0.2375190258026123
 0.120121955871582
 0.1255669593811035
 0.1533877849578857
 0.2375149726867676
 0.1432549953460693
 0.147892951965332
 0.1366369724273682
 0.05409097671508789
 0.06976199150085449
 0.07643890380859375
 0.1372079849243164
 0.2372980117797852
 0.1424272060394287
 0.09881687164306641
 0.1590049266815186
 0.2052850723266602
 0.2154159545898438
 0.160383939743042
 0.2257981300354004
 0.143010139465332
 0.1812951564788818
 0.1981649398803711
 0.1422250270843506
 0
 0.4539470672607422
 0.1984779834747314
 0.09257006645202637
 0.1202199459075928
 0.3045699596405029
 0.1930990219116211
 0.3547730445861816
 0.165410041809082
 0.1595299243927002
 0.09307312965393066
 0.03644800186157227
 0.1486778259277344
 0.09255194664001465
 0.06983590126037598
 0.1717188358306885
 0.137782096862793
 0.08661007881164551
 0.1814119815826416
 0.2091329097747803
 0.06440186500549316
 0.1987500190734863
 0.08654117584228516
 0.136970043182373
 0.2821991443634033
 0.23757004737854
 0.1091468334197998
 0.2775280475616455
 0.1259491443634033
 0.1034090518951416
 0.0590519905090332
 0.1441400051116943
 0.06107497215270996
 3.536771059036255
 0.350473165512085
 0.1813280582427979
 0.1592690944671631
 0.2764840126037598
 0.1200687885284424
 0.2037551403045654
 0.1983461380004883
 0.08096599578857422
 0.05864715576171875
 0.2041740417480469
 0.04188108444213867
 0.2542459964752197
 0.2044970989227295
 0.2149090766906738
 0.1033811569213867
 0.1324059963226318
 0.1254751682281494
 0.1759140491485596
 0.04862689971923828
 0.1426661014556885
 0.1036028861999512
 0.05391192436218262
 0.09274101257324219
 0.06431198120117188
 0.06138896942138672
 0.06412506103515625
 0.2544739246368408
 0.1313941478729248
 0.2500648498535156
 0.09370207786560059
 0.07556319236755371
 0.1429018974304199
 0.1039230823516846
 0.06482601165771484
 0.04177594184875488
 0.06455183029174805
 0.1032569408416748
 0.06457400321960449
 0.03774809837341309
 0.06981897354125977
 0.06986308097839355
 0.2337198257446289
 0.1890630722045898
 0.2210350036621094
 0.0646519660949707
 0.06974101066589355
 1.625237941741943
 0.1696321964263916
 0.2049832344055176
 0.09926509857177734
 0.02510690689086914
 0.05357480049133301
 0.1036880016326904
 0.05322504043579102
 0.04744887351989746
 0.0264430046081543
 0.008491992950439453
 0.03789997100830078
 0.01414012908935547
 0.1095728874206543
 0.07480001449584961
 0.05320000648498535
 0.1427228450775146
 0.1873490810394287
 0.03085899353027344
 0.1088480949401855
 0.1257748603820801
 1.334143877029419
 0.1928250789642334
 0.1146280765533447
 0.07645392417907715
 0.07542800903320312
 1.27721095085144
 0.1533260345458984
 0.06981992721557617
 0.05346989631652832
 0.04173088073730469
 0.06414914131164551
 0.05900001525878906
 0.05313587188720703
 0.03673100471496582
 0.1369390487670898
 0.07552409172058105
 0.02504801750183105
 0.02567720413208008
 0.09785819053649902
 0.06961917877197266
 0.06978487968444824
 0.1091339588165283
 0.04183197021484375
 0.09244894981384277
 0.05956888198852539
 0.03075098991394043
 0.05317497253417969
 0.08685684204101562
 0.1701340675354004
 0.1259050369262695
 0.09119486808776855
 0.0253899097442627
 0.136476993560791
 0.0144040584564209
 0.08737397193908691
 0.0643610954284668
 0.01469111442565918
 1.879771947860718
 0.2211160659790039
 0.1591877937316895
 1.575173139572144
 0.2537209987640381
 0.103085994720459
 0.1043159961700439
 0.05310988426208496
 0.08091402053833008
 1.540204048156738
 0.3270390033721924
 1.511621952056885
 0.1811470985412598
 0.2211830615997314
 0.1426601409912109
 0.01431798934936523
 0.09875917434692383
 0.01482701301574707
 1.242568969726562
 0.2147078514099121
 1.445734024047852
 0.3948509693145752
 0.1815619468688965
 0.1984519958496094
 0.1369059085845947
 0.06976604461669922
 0.1646420955657959
 0.2610399723052979
 0.1771438121795654
 1.280950784683228
 0.1927030086517334
 0.1756191253662109
 0.125892162322998
 0.0640571117401123
 0.1299810409545898
 0.008310079574584961
 1.204787969589233
 0.2274749279022217
 0.06416797637939453
 0.103877067565918
 0.1327879428863525
 0.04752302169799805
 0.04175901412963867
 0.1099319458007812
 0.01409411430358887
 0.03110098838806152
 0.06022405624389648
 0.03737401962280273
 0.03098702430725098
 0.1089410781860352
 0.01400899887084961
 0.20943284034729
 0.09919309616088867
 0.08130788803100586
 0.1329901218414307
 0.1094510555267334
 0.008459806442260742
 0.08683896064758301
 0.1369600296020508
 0
 0.7302751541137695
 0.2553060054779053
 0.08727097511291504
 0.05850005149841309
 0.08073592185974121
 0.7822060585021973
 0.1815621852874756
 0.09336090087890625
 0.1759700775146484
 0.1480967998504639
 0.08111000061035156
 0.08060383796691895
 0.09758210182189941
 0.06417393684387207
 0.03135490417480469
 0.04743504524230957
 0.06422305107116699
 0.04824209213256836
 0.03197908401489258
 0.08246397972106934
 0.04222202301025391
 1.356867074966431
 0.1478559970855713
 1.24760913848877
 0.1999969482421875
 0.1922421455383301
 0.04217290878295898
 0.08669590950012207
 0.04734301567077637
 1.192731142044067
 0.2437400817871094
 0.2328219413757324
 0.07035303115844727
 0.1497159004211426
 0.2541899681091309
 0.05297398567199707
 0.1146960258483887
 0.1422920227050781
 0.04731988906860352
 0.1201012134552002
 0.07533907890319824
 0.01388406753540039
 0.0863499641418457
 0.04320693016052246
 0.0599970817565918
 0.1101510524749756
 0.06027102470397949
 0.03069305419921875
 0.1421568393707275
 0.06968498229980469
 1.214632987976074
 0.2042250633239746
 0.182020902633667
 0.1033508777618408
 0.02139019966125488
 0.1541469097137451
 0.02526092529296875
 0.02510309219360352
 0.4055240154266357
 0.1273360252380371
 0.1648118495941162
 0.1479568481445312
 0.08645391464233398
 0.1269440650939941
 0.09333300590515137
 0.05863499641418457
 0.09802007675170898
 0.04733490943908691
 0.01412296295166016
 1.249562978744507
 0.2038769721984863
 0.03718805313110352
 0.01999807357788086
 0.009253025054931641
 0.04185199737548828
 1.153950929641724
 0.3042199611663818
 1.314877986907959
 0.1535308361053467
 0.192547082901001
 0.06035208702087402
 0.04781508445739746
 0.1258888244628906
 1.404710054397583
 0.2163429260253906
 0.1312808990478516
 0.03087401390075684
 0.08115196228027344
 0.06404399871826172
 0.03619909286499023
 0.008322000503540039
 0.07545900344848633
 1.310199975967407
 0.3152298927307129
 0.1984789371490479
 0.1312689781188965
 0.1823360919952393
 0.07558608055114746
 0.0200200080871582
 0.1587378978729248
 0.075469970703125
 1.198164939880371
 0.1494770050048828
 0.1982219219207764
 0.0531160831451416
 0.1987841129302979
 0.1645138263702393
 1.287317037582397
 0.2098209857940674
 0.1720800399780273
 0.008477926254272461
 0.1258389949798584
 0.125687837600708
 0.08642697334289551
 0.08103299140930176
 0.06995797157287598
 0.03060793876647949
 1.25989294052124
 0.164553165435791
 1.064781188964844
 0.09361386299133301
 0.231889009475708
 0.03626894950866699
 1.294289112091064
 0.1815218925476074
 1.393929958343506
 0.3884298801422119
 0.1649210453033447
 0.04891204833984375
 0.03089308738708496
 0.0600438117980957
 1.076451063156128
 0.07000494003295898
 0.1088259220123291
 1.074579954147339
 1.185322999954224
 0.2702031135559082
 0.1266570091247559
 0.2478799819946289
 0.1032669544219971
 1.466484069824219
 0.2262568473815918
 0.1714038848876953
 1.508158922195435
 0.1368730068206787
 0.09291195869445801
 0.05856990814208984
 0.0367581844329834
 0.09283995628356934
 1.228089809417725
 0.1310157775878906
 0.2428081035614014
 1.160794973373413
 0.114976167678833
 0.09866094589233398
 0.01408195495605469
 1.232246875762939
 0.09206914901733398
 0.01536202430725098
 0.01405215263366699
 0.1598050594329834
 1.173485994338989
 0.3442971706390381
 0.1660969257354736
 0.03078699111938477
 0.1198160648345947
 0.08690881729125977
 0.05858111381530762
 0.1328880786895752
 0.1255021095275879
 0.04732990264892578
 0.1546931266784668
 0.08237600326538086
 0.1265349388122559
 0.13189697265625
 0.210319995880127
 0.01893997192382812
 0.05381298065185547
 0.1150238513946533
 1.131051063537598
 0.09197115898132324
 0.2540459632873535
 1.256269931793213
 0.1369638442993164
 0.1151950359344482
 1.144779920578003
 0.04755496978759766
 0.3663110733032227
 1.484034061431885
 0.1366910934448242
 0.1031670570373535
 0.06420087814331055
 0.06421279907226562
 0.08293795585632324
 0.0417788028717041
 0.1649889945983887
 0.1371860504150391
 0.08639693260192871
 0.09767603874206543
 0.07540202140808105
 0.04732298851013184
 0.1421768665313721
 0.1145901679992676
 0.06996703147888184
 0.3555190563201904
 0
 0.7627711296081543
 0.3154737949371338
 5.168004035949707
 0.3988628387451172
 0.2939021587371826
 0.1815769672393799
 0.06004810333251953
 0.1537950038909912
 0.1200048923492432
 1.319157123565674
 0.2489950656890869
 0.1814019680023193
 0.1591589450836182
 0.1982159614562988
 0.06416416168212891
 0.03639793395996094
 0.08142304420471191
 0.104780912399292
 0.1101620197296143
 0.04733586311340332
 0.03123307228088379
 0.09321284294128418
 0.08079886436462402
 0.198077917098999
 0.1255218982696533
 0.1144731044769287
 0.2540669441223145
 0.06977605819702148
 0.09764695167541504
 0.0697481632232666
 0.05422592163085938
 0.1876270771026611
 0.1144969463348389
 0.03058695793151855
 0.1759557723999023
 0.1153531074523926
 0.0363309383392334
 0.1591207981109619
 0.08117914199829102
 0.008196830749511719
 0.2375259399414062
 0.0697329044342041
 0.06975483894348145
 0.02516794204711914
 0.1425201892852783
 1.460708141326904
 0.3375329971313477
 0.1937520503997803
 0.06409788131713867
 0.1591081619262695
 0.1490399837493896
 1.333847045898438
 0.1145889759063721
 0.2093019485473633
 0.00848388671875
 0.5707969665527344
 0.1925408840179443
 0.0083160400390625
 0.1813788414001465
 0.2373349666595459
 0.008296966552734375
 0.12546706199646
 0.09379100799560547
 0.004028081893920898
 0.1264801025390625
 0.1645660400390625
 0.1256999969482422
 0.2090921401977539
 0.08667111396789551
 1.17326283454895
 0.08832502365112305
 0.210662841796875
 0.0937199592590332
 0.1159520149230957
 0.1033141613006592
 0.1254980564117432
 0.02501988410949707
 0.1421909332275391
 0.04180002212524414
 0.05311298370361328
 0.1258640289306641
 0.1033658981323242
 0.2113420963287354
 0.1368989944458008
 0.0807650089263916
 0.02504205703735352
 0.1721389293670654
 0.05350804328918457
 0.09762907028198242
 0.1646080017089844
 1.242425203323364
 0.1817550659179688
 0.1982781887054443
 0.06415987014770508
 0.1366679668426514
 0.0475311279296875
 0.1818130016326904
 0.1535260677337646
 0.1924440860748291
 0.1645441055297852
 0.1420390605926514
 0.1029300689697266
 0.08626699447631836
 0.08631491661071777
 0.09213590621948242
 0.02538394927978516
 0.2204468250274658
 0.1265900135040283
 0.03755092620849609
 0.1150429248809814
 0.1487948894500732
 0.01950693130493164
 0.1703140735626221
 0.1535038948059082
 0.09765005111694336
 0.1034400463104248
 0.1093950271606445
 0.09291696548461914
 0.05321383476257324
 0.09398388862609863
 0.2109570503234863
 0.2099339962005615
 0.1815280914306641
 0.0707848072052002
 1.476731061935425
 0.2711939811706543
 0.07568001747131348
 0.0641939640045166
 0.1552479267120361
 1.210247039794922
 0.07564210891723633
 1.074213027954102
 0.06435513496398926
 0.05380010604858398
 0.04213690757751465
 0.07636809349060059
 1.19271993637085
 0.1310789585113525
 0.1192219257354736
 0.1876330375671387
 0.1198799610137939
 0.03104686737060547
 0.198267936706543
 0.1198430061340332
 0.1098129749298096
 0.1929681301116943
 0.1769769191741943
 1.179286956787109
 0.288905143737793
 0.2103371620178223
 0.05381584167480469
 0.05324912071228027
 0.3543050289154053
 0.1256279945373535
 0.3726661205291748
 0.06965208053588867
 0.03617596626281738
 0.1715469360351562
 0.09745001792907715
 0.04166817665100098
 0.04793190956115723
 0.0868070125579834
 0.03645586967468262
 0.1993319988250732
 0.1547279357910156
 0.1198549270629883
 0.1925539970397949
 0.09391283988952637
 0.1759130954742432
 0.1758389472961426
 0.05293798446655273
 1.248771905899048
 0.3840470314025879
 0.1421811580657959
 0.05347800254821777
 0.04728817939758301
 0.1589479446411133
 0.0865170955657959
 0.09759807586669922
 0.2317419052124023
 0.03069090843200684
 0.08079314231872559
 0.05286097526550293
 0.008235931396484375
 0.09755897521972656
 0.04917311668395996
 0.008330821990966797
 0.008179903030395508
 0.3821101188659668
 0.03061389923095703
 1.141754150390625
 0.2598650455474854
 0.05293011665344238
 0.0250248908996582
 0.06499695777893066
 0.05302786827087402
 1.181607007980347
 0.3827011585235596
 0.09229898452758789
 0.1542708873748779
 0.09865593910217285
 0.05921196937561035
 0.06020712852478027
 0.2595601081848145
 0.1760029792785645
 0.05859923362731934
 0.2539918422698975
 0.09330487251281738
 0.1488008499145508
 0.1031630039215088
 0.009685039520263672
 0.1922988891601562
 0.1262578964233398
 0.008914947509765625
 0.1202569007873535
 0.0475459098815918
 1.069000959396362
 1.181030988693237
 0.1983921527862549
 0.06406497955322266
 0.2260169982910156
 0.07644295692443848
 1.322870969772339
 0.1425909996032715
 0.1644318103790283
 0.03653597831726074
 0.07540202140808105
 1.14842700958252
 0.1312639713287354
 0.2273769378662109
 0.5423679351806641
 0.04204511642456055
 0.1089258193969727
 0.09231305122375488
 0.03066587448120117
 0.203563928604126
 0.01399683952331543
 0.03075194358825684
 1.42252779006958
 0.2205078601837158
 0.04784083366394043
 0.1477649211883545
 0.1258301734924316
 1.348262786865234
 0.317047119140625
 0.1425349712371826
 0.1098558902740479
 0.1146509647369385
 0.08220314979553223
 0.05303621292114258
 1.208197116851807
 0.1477758884429932
 0.05296921730041504
 0.1595368385314941
 0.08667397499084473
 0.05324912071228027
 0.1998679637908936
 0.1427249908447266
 1.142881155014038
 0.1147100925445557
 0.1587409973144531
 0.1596159934997559
 0.008208036422729492
 0.1256940364837646
 0.2264580726623535
 0.1255099773406982
 0.1757309436798096
 0.1755690574645996
 0.110680103302002
 0.1092450618743896
 0.03064894676208496
 0.415701150894165
 0.1365301609039307
 1.21626615524292
 0.3556389808654785
 0.1982309818267822
 1.479480981826782
 0.2479701042175293
 0.07516598701477051
 1.204500198364258
 0.1851649284362793
 0.10306715965271
 1.147318840026855
 0.19222092628479
 0.1589429378509521
 0.1259570121765137
 0.09758806228637695
 0.06551194190979004
 0.02646493911743164
 0.07050800323486328
 0.1482398509979248
 0.02620291709899902
 1.255185127258301
 0.1872611045837402
 0.1143949031829834
 0.08097982406616211
 0.1988461017608643
 0.1108560562133789
 0.1481587886810303
 0.1153609752655029
 0.1370339393615723
 0.1877408027648926


# name: avgTeste
# type: scalar
0.2393802801767985


# name: antecipatedresponseT
# type: matrix
# rows: 1
# columns: 3
 2 1 3


