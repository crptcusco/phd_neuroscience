# Created by Octave 4.2.2, Thu Dec 03 20:12:35 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
006


# name: age
# type: sq_string
# elements: 1
# length: 2
22


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 6 1 3 5 2 4


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 0.4575748443603516
 0.2934999465942383
 0.1760969161987305
 0.4504630565643311
 0.1594491004943848
 0.03075790405273438


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.2613069613774617


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.3835310935974121
 0.1427240371704102
 0.271543025970459
 0.2101750373840332
 0.01034903526306152
 0.2328300476074219
 0.0363609790802002
 1.507465124130249
 0.5121340751647949
 0.2044248580932617
 0.01955699920654297
 0.008597850799560547
 0.08783984184265137
 1.191229820251465
 0.1492509841918945
 0.02649307250976562
 1.09508490562439
 0.428455114364624
 0.2605869770050049
 0.2605381011962891
 0.1773221492767334
 0.1205132007598877
 0.06049799919128418
 0.03646492958068848
 1.347249031066895
 0.2213699817657471
 1.151283025741577
 0.08834195137023926
 0.05336785316467285
 0.07683706283569336
 0.03454995155334473
 1.10735297203064
 0.2610499858856201
 0.1262071132659912
 0.04766988754272461
 0.1712181568145752
 0.1936559677124023
 1.078550100326538
 0.1538610458374023
 0.1427679061889648
 0.02526402473449707
 0.09320306777954102
 0.9557030200958252
 0.05883908271789551
 0.07028317451477051
 0.04313921928405762
 1.056048154830933
 0.3501381874084473
 0.1541290283203125
 0.1091489791870117
 0.165330171585083
 0.05871987342834473
 1.084759950637817
 0.2547869682312012
 0.06599998474121094
 1.022627830505371
 0.1595528125762939
 0.01963305473327637
 0.01981997489929199
 0.1819939613342285
 0.01964306831359863
 0.009921789169311523
 0.0867462158203125
 1.375653028488159
 0.03633689880371094
 0.1329391002655029
 0.07679486274719238
 1.066255807876587
 0.3443701267242432
 0.03218197822570801
 1.050085067749023
 0.1596798896789551
 0.1042289733886719
 0.1092770099639893
 0.1091711521148682
 0.01937985420227051
 0.91786789894104
 0.1202681064605713
 0.008372068405151367
 0.04204607009887695
 0.03692507743835449
 0.04775190353393555
 0.9879999160766602
 0.1554100513458252
 0.07552695274353027
 0.09864497184753418
 0.1485278606414795
 1.073251008987427
 0.03742098808288574
 0.1098349094390869
 0.02011990547180176
 0.0425269603729248
 0.1594669818878174
 0.9232652187347412
 0.02530503273010254
 0.3440752029418945
 0.1984860897064209
 0.08271694183349609
 0.04800009727478027
 1.010154008865356
 0.04342794418334961
 0.03666901588439941
 0.02148985862731934
 0.01967501640319824
 0.3636658191680908
 0.02141880989074707
 0.03647613525390625
 0.1547000408172607
 0.01992607116699219
 0.960709810256958
 0.1597659587860107
 0.01398301124572754
 0.03085494041442871
 0.08260798454284668
 1.110968828201294
 0.01449799537658691
 0.008666038513183594
 0.0595550537109375
 0.0477910041809082
 0.1817638874053955
 0.06990599632263184
 0.4093561172485352
 0.2214038372039795
 0.1443068981170654
 0.05330896377563477
 0.03645610809326172
 1.051403999328613
 0.04817581176757812
 1.330698013305664
 0.09227514266967773
 0.9270761013031006
 0.1485679149627686
 0.03658390045166016
 1.035712003707886
 0.06995916366577148
 1.362423181533813
 0.04749107360839844
 0.1654388904571533
 0.03645586967468262
 0.02608394622802734
 0.2831299304962158
 0.01393008232116699
 0.1765620708465576
 1.262044906616211
 0.06556296348571777
 0.1203498840332031
 0.09273409843444824
 1.145677089691162
 1.140474081039429
 0.09278607368469238
 0.3945820331573486
 0.02036285400390625
 0.08114504814147949
 0.03076004981994629
 0.06435394287109375
 0.008344888687133789
 1.105918884277344
 0.1204228401184082
 0.03139996528625488
 1.093554973602295
 0.1092579364776611
 0.09852099418640137
 0.03688502311706543
 0.03109002113342285
 0.00860595703125
 1.093775987625122
 0.07587504386901855
 0.01957893371582031
 1.115662097930908
 0.2785530090332031
 0.05455398559570312
 1.218431949615479
 0.0147249698638916
 0.0309760570526123
 1.08405613899231
 2.10186505317688
 0.1270930767059326
 1.141578912734985
 0.06431913375854492
 0.03650188446044922
 1.051019906997681
 0.01411008834838867
 0.09242606163024902
 1.201838970184326
 1.57719612121582
 0.1203389167785645
 1.049860000610352
 1.312718152999878
 0.1096010208129883
 0.02518200874328613
 0.2601079940795898
 1.400975942611694
 0.0921931266784668
 0.1872701644897461
 1.772497177124023
 0.01944589614868164
 0.2321369647979736
 0.1877279281616211
 0.05317997932434082
 0.03083205223083496
 0.0364079475402832
 0.05330801010131836
 1.229111194610596
 0.3275589942932129
 0.1706578731536865
 0.4342091083526611
 0.2437539100646973
 0.03633308410644531
 0.103646993637085
 0.2975180149078369
 0.03623318672180176
 0.1262431144714355
 0.1427919864654541
 0.01404500007629395
 1.309733152389526
 0.2098259925842285
 0.05341410636901855
 0.04750394821166992
 0.09405279159545898
 0.01957106590270996
 0.05304384231567383
 0.05388593673706055
 0.03697299957275391
 0.02046704292297363
 0.01010704040527344
 1.414247989654541
 0.5349709987640381
 0.08112406730651855
 0.1090869903564453
 0.008491992950439453
 0.04771900177001953
 0.03085613250732422
 0.1932389736175537
 0.2548189163208008
 0.4577310085296631
 0.1259329319000244
 0.1768169403076172
 0.0649268627166748
 0.3614239692687988
 0.1373100280761719
 0.009144067764282227
 0.03741002082824707
 0.05373907089233398
 0.0367119312286377
 1.150466918945312
 1.430202960968018
 0.04903912544250488
 1.388870000839233
 0.08698415756225586
 0.08148288726806641
 1.117477893829346
 0.1658759117126465
 0.4677059650421143
 0.004580974578857422
 0.2441079616546631
 0.03681302070617676
 0.03067493438720703
 0.08133316040039062
 0.04363918304443359
 0.02024102210998535
 0.07640314102172852
 0.04753613471984863
 0.008317947387695312
 0.03755593299865723
 0.0200498104095459
 1.195393085479736
 0.1538701057434082
 0.2887601852416992
 0.1986610889434814
 0.04200410842895508
 0.05319499969482422
 0.1942038536071777
 0.08719015121459961
 0.01947808265686035
 0.09242606163024902
 0.2658348083496094
 0.4113378524780273
 0.4838309288024902
 0.2045729160308838
 0.4514238834381104
 0.05317807197570801
 0
 1.790621995925903
 0.9324131011962891
 0.2941040992736816
 0.5698039531707764
 0.2606480121612549
 0.3339571952819824
 0.03085112571716309
 0.1998960971832275
 0.3401000499725342
 0.1541450023651123
 0.1205201148986816
 0.1650669574737549
 1.436357975006104
 0.09376096725463867
 0.1426880359649658
 0.05367588996887207
 0.01963210105895996
 0.03724408149719238
 0.4483959674835205
 0.1654009819030762
 0.2321939468383789
 0.1873900890350342
 0.2883980274200439
 0.4130849838256836
 0.2600908279418945
 0.02738595008850098
 0.1595280170440674
 0.0204160213470459
 1.301041841506958
 0.2209069728851318
 0.07665085792541504
 0.2210431098937988
 0.3330540657043457
 0.1091639995574951
 0.2615349292755127
 0.2223079204559326
 0.1426799297332764
 0.01406216621398926
 0.0586540699005127
 0.1090800762176514
 1.227953910827637
 0.5959491729736328
 0.07018208503723145
 0.05404114723205566
 0.1035628318786621
 0.09878706932067871
 0.1822619438171387
 0.2051069736480713
 0.1877439022064209
 0.1425559520721436
 0.06434202194213867
 0.1091079711914062
 0.03640890121459961
 0.1819920539855957
 0.0139920711517334
 0.03075885772705078
 0.03644514083862305
 0.2435019016265869
 1.078407049179077
 0.1878221035003662
 0.1035430431365967
 0.2435498237609863
 0.08717894554138184
 0.05879306793212891
 1.157529830932617
 0.2041499614715576
 0.3611810207366943
 0.2664132118225098
 0.2046418190002441
 0.05308103561401367
 0.103585958480835
 0.1650199890136719
 0.05905914306640625
 1.087766885757446
 0.1987919807434082
 0.06977009773254395
 0.1203079223632812
 0.1372179985046387
 0.1257638931274414
 1.212311029434204
 0.2505631446838379
 0.06429815292358398
 1.262754917144775
 0.3834919929504395
 0.3228249549865723
 0.4906430244445801
 0.2382271289825439
 0.3556251525878906
 0.2170119285583496
 0.5683131217956543
 0.1939129829406738
 0.1427099704742432
 0.1649878025054932
 0.04771995544433594
 0.04253292083740234
 0.08669185638427734
 0.228402853012085
 0.02136015892028809
 0.05315709114074707
 1.059998989105225
 0.1202871799468994
 0.1264309883117676
 0.3791301250457764
 0.1095199584960938
 0.1320500373840332
 1.175826072692871
 0.01958799362182617
 0.1481790542602539
 0.1152181625366211
 0.1100060939788818
 0.3726420402526855
 0.04745221138000488
 0.04758620262145996
 0.00836181640625
 0.04203009605407715
 1.038514137268066
 0.2717618942260742
 0.1166369915008545
 0.4122748374938965
 0.04767394065856934
 0.1327989101409912
 0.3270668983459473
 0.05917906761169434
 0.07634592056274414
 0.1945559978485107
 1.342355012893677
 0.05891203880310059
 0.4067440032958984
 0.2907371520996094
 0.2106320858001709
 0.2452521324157715
 0.2772319316864014
 0.3963119983673096
 0.2828810214996338
 0.2536389827728271
 0.08679914474487305
 0.07697296142578125
 0.2493619918823242
 0.03663802146911621
 0.0307159423828125
 0.09244322776794434
 0.05422306060791016
 0.05897903442382812
 0.06442117691040039
 0.03652000427246094
 0.0700380802154541
 0.0605318546295166
 0.03087592124938965
 0.03654694557189941
 0.105241060256958
 0.008996963500976562
 0.1817300319671631
 0.0978240966796875
 0.2208948135375977
 0.08284497261047363
 0.2546839714050293
 0.4573791027069092
 0.3104109764099121
 0.1715478897094727
 0.03629899024963379
 0.2934541702270508
 0.2769739627838135
 0.3602440357208252
 0.02559399604797363
 0.1762590408325195
 1.149322986602783
 0.0251460075378418
 0.1829040050506592
 0.5572578907012939
 0.03659796714782715
 0.1706039905548096
 0.06983304023742676
 0.2046000957489014
 0.2442910671234131
 0.09196686744689941
 0.07571101188659668
 0.1039159297943115
 0.05990815162658691
 0.03640484809875488
 0.04365086555480957
 0.09249091148376465
 0.02071905136108398
 0.104032039642334
 0.02548408508300781
 1.13483190536499
 0.1711089611053467
 0.126309871673584
 0.04781198501586914
 0.1375739574432373
 0.1553759574890137
 0.2828841209411621
 0.04282307624816895
 0.1648402214050293
 0.0770561695098877
 0.03093099594116211
 0.05317997932434082
 0.1385078430175781
 0.1259620189666748
 0.2774391174316406
 0.05312514305114746
 0.05310201644897461
 0.008588075637817383
 1.083792924880981
 0.1593329906463623
 0.3154680728912354
 0.2214829921722412
 0.1483359336853027
 0.1276190280914307
 1.734241962432861
 0.2232828140258789
 0.1819109916687012
 0.2155029773712158
 0.2994859218597412
 0.3674860000610352
 0.3106479644775391
 0.2154359817504883
 0.249345064163208
 0.08119797706604004
 0.1317908763885498
 0.2546300888061523
 1.072468042373657
 0.2602450847625732
 0.1652660369873047
 0.650629997253418
 0.2545230388641357
 0.1594750881195068
 0.2268221378326416
 0.198822021484375
 0.07720804214477539
 0.2603390216827393
 0.3800380229949951
 0.1873950958251953
 0.2489597797393799
 0.1431140899658203
 0.07003092765808105
 1.061060905456543
 0.2444419860839844
 0.09799504280090332
 1.029760122299194
 0.2662718296051025
 0.05870723724365234
 0.05309295654296875
 0.1034920215606689
 0.125931978225708
 0.03631114959716797
 0.1482930183410645
 0.06604695320129395
 0.04756379127502441
 0.1429250240325928
 0.3795201778411865
 0.1820189952850342
 0.1989209651947021
 0.182136058807373
 0.09263205528259277
 0.1987519264221191
 0.08244705200195312
 0.2830779552459717
 0.3443269729614258
 0.1424999237060547
 0.07613587379455566
 0.1158959865570068
 0.03081512451171875
 1.084839105606079
 0.2210478782653809
 0.1259059906005859
 0.181995153427124
 0.08671402931213379
 0.06979918479919434
 0.3607919216156006
 0.3499798774719238
 0.5895488262176514
 0.04252910614013672
 0.1711018085479736
 0.7361249923706055
 0.115041971206665
 0.07004714012145996
 0.1427099704742432
 1.234464883804321
 0.3280179500579834
 0.1090960502624512
 1.236397981643677
 0.2379770278930664
 0.2728819847106934
 0.4293279647827148
 0.2546908855438232
 0.1761679649353027
 0.193695068359375
 0.1217010021209717
 0.04746007919311523
 0.08673906326293945
 0.06074213981628418
 0.1161351203918457
 0.1876709461212158
 0.1831378936767578
 0.01403284072875977
 1.111612796783447
 0.1597909927368164
 0.07577180862426758
 0.07024812698364258
 0.1262409687042236
 1.268399000167847
 1.189139127731323
 0.209665060043335
 0.09932279586791992
 0.2211711406707764
 0.2100820541381836
 0.299713134765625
 0.1595330238342285
 0.1653709411621094
 0.06480503082275391
 0.0196840763092041
 0.0756680965423584
 0.2340779304504395
 0.1503300666809082
 0.1262187957763672
 0.01955389976501465
 0.03067588806152344
 0.06426906585693359
 0.3346960544586182
 0.03043508529663086
 0.0368950366973877
 0.02640199661254883
 0.008335113525390625
 0.1821820735931396
 0.1818950176239014
 0.06427502632141113
 0.1331110000610352
 0.009047031402587891
 1.285383224487305
 0.2329421043395996
 0.7150571346282959
 0.01965212821960449
 0.3402168750762939
 0.2599442005157471
 1.049348115921021
 0.2112147808074951
 0.371635913848877
 0.3103170394897461
 0.3278250694274902
 0.09243202209472656
 0.103410005569458
 0.04366707801818848
 0.0922081470489502
 0.3554830551147461
 0.153886079788208
 0.132253885269165
 0.2828361988067627
 0.008424043655395508
 0.293752908706665
 0.08245301246643066
 0.2711100578308105
 0.26021409034729
 0.395780086517334
 0.2501869201660156
 0.1482548713684082
 0.3006489276885986
 0.1762747764587402
 0.1088869571685791
 0.0363309383392334
 0.1708331108093262
 0.1487190723419189
 0.2215280532836914
 0.3554890155792236
 0.2212178707122803
 0.216015100479126
 0.02120208740234375
 0.3105449676513672
 0.2939491271972656
 0.171950101852417
 0.3163681030273438
 0.2939209938049316
 0.1036598682403564
 0.2043311595916748
 0.1877110004425049
 0.2770841121673584
 0.2042429447174072
 0.04749107360839844
 0.125993013381958
 0.1147041320800781
 0.01389479637145996
 0.148223876953125
 0.07567811012268066
 0.181840181350708
 0.2211580276489258
 0.2936949729919434
 0.09220600128173828
 0.4569969177246094
 0.05882000923156738
 0.3106138706207275
 0.1427130699157715
 0.1039700508117676
 0.08120894432067871
 0.05329799652099609
 0.0587460994720459
 0.1034550666809082
 0.1607809066772461
 0.104435920715332
 0.03641796112060547
 0.1260499954223633
 0.1777369976043701
 0.03076004981994629
 0.1202762126922607
 0.07662487030029297
 0.1259779930114746
 0.02518010139465332
 0.153831958770752
 0.06530904769897461
 0.2156009674072266
 0.2660629749298096
 0.05336785316467285
 0.2106819152832031
 0.05309391021728516
 0.1653039455413818
 0.3499658107757568
 1.286360025405884
 0.1482300758361816
 0.04750514030456543
 0.06543993949890137
 0.07561302185058594
 0.2041449546813965
 0.1092529296875
 0.05864715576171875
 0.1202681064605713
 0.1705880165100098
 1.140320062637329
 0.1987419128417969
 0.03081202507019043
 0.1430051326751709
 0.2226619720458984
 0.05324196815490723
 0.06505417823791504
 0.1258020401000977
 0.04193282127380371
 0.2440290451049805
 0.0886847972869873
 0.2335820198059082
 0.5862569808959961
 0.187385082244873
 0.03632497787475586
 1.078227996826172
 0.5065209865570068
 0.3967189788818359
 0.05991101264953613
 0.1826999187469482
 1.223130941390991
 0.2938079833984375
 1.23964786529541
 0.03629302978515625
 0.2320919036865234
 0.02643299102783203
 0.1049139499664307
 0.9818961620330811
 1.192468881607056
 0.01389503479003906
 0.1095139980316162
 0.07686185836791992
 0.04303383827209473
 0.1426980495452881
 0.1210281848907471
 0.1652050018310547
 0.1660878658294678
 1.350382089614868
 0.06541180610656738
 0.1089270114898682
 0.2156140804290771
 0.1594648361206055
 0.4418299198150635
 0.1714208126068115


# name: avgTeste
# type: scalar
0.2738174015680949


# name: antecipatedresponseT
# type: scalar
2


