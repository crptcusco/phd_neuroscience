# Created by Octave 4.2.2, Mon Dec 07 20:00:14 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
009


# name: age
# type: sq_string
# elements: 1
# length: 2
25


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 3 2 1 6 4 5


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 1.560379028320312
 0.2434070110321045
 0.1817362308502197
 0.1820378303527832
 0.1546080112457275
 0.7436370849609375


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.5109675327936808


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 0
# columns: 0


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 3
 1 1 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.2044370174407959
 0.06494498252868652
 0.1879940032958984
 0.2828199863433838
 0.350365161895752
 0.126054048538208
 0.2011480331420898
 0.2214870452880859
 0.1987299919128418
 0.2155749797821045
 0.284203052520752
 0.1318249702453613
 0.1482679843902588
 0.1712028980255127
 0.07684612274169922
 0.1373269557952881
 0.08692097663879395
 0.2882788181304932
 0.3286609649658203
 0.1876389980316162
 1.205772161483765
 0.396338939666748
 0.4726109504699707
 0.384181022644043
 0.7079570293426514
 0.3066048622131348
 0.2839651107788086
 0.2892000675201416
 0.1038401126861572
 0.06441283226013184
 0.2834069728851318
 0.1319911479949951
 0.2278749942779541
 0.3229789733886719
 0.20005202293396
 0.1989569664001465
 0.2832508087158203
 0.2831411361694336
 0.127810001373291
 0.1836090087890625
 0.1148800849914551
 0.15982985496521
 0.2003200054168701
 0.3331518173217773
 0.2109911441802979
 0.6576008796691895
 0.3328831195831299
 0.2885050773620605
 0.3851499557495117
 0.1230490207672119
 0.434276819229126
 0.2290158271789551
 0.1536750793457031
 0.3338110446929932
 0.2659289836883545
 0.1484601497650146
 0.2771039009094238
 0.1932361125946045
 0.09235095977783203
 0.2211952209472656
 0.2333219051361084
 0.5965530872344971
 0.1987030506134033
 0.2267608642578125
 0.3561139106750488
 0.2046008110046387
 0.6755580902099609
 0.1372959613800049
 0.1488139629364014
 0.2377569675445557
 0.3498990535736084
 0.4171080589294434
 0.3395028114318848
 0.1315350532531738
 0.1987130641937256
 0.9367568492889404
 0.09215211868286133
 0.2097699642181396
 0.07015395164489746
 0.193774938583374
 0.2545850276947021
 0.3327271938323975
 0.6025111675262451
 0.2612009048461914
 0.05300211906433105
 0.1536579132080078
 0.2449450492858887
 0.0432579517364502
 0.06445598602294922
 0.2783758640289307
 0.1932542324066162
 0.2605340480804443
 0.1717069149017334
 0.05306291580200195
 0.1147639751434326
 0.3722021579742432
 0.09221601486206055
 0.4166738986968994
 0.2209320068359375
 0.1047511100769043
 0.1425938606262207
 0.3278050422668457
 0.0816810131072998
 0.2209188938140869
 0.2544970512390137
 0.8134911060333252
 0.1313869953155518
 0.07140016555786133
 0.1985540390014648
 0.09236717224121094
 0.1089558601379395
 0.1664359569549561
 0.06445193290710449
 0.09944701194763184
 0.0769038200378418
 0.07634806632995605
 0.137117862701416
 0.08691811561584473
 0.08170795440673828
 0.1721909046173096
 0.238286018371582
 0.03101086616516113
 0.3001761436462402
 0.4343709945678711
 0.3565738201141357
 0.1935100555419922
 0.109407901763916
 0.2109329700469971
 0.3055329322814941
 0.08732700347900391
 0.1098461151123047
 0.6939318180084229
 0.4127209186553955
 0.545712947845459
 0.04766201972961426
 0.04785704612731934
 0.08124089241027832
 0.227139949798584
 0.698462963104248
 0.08271217346191406
 0.0765998363494873
 0.2101089954376221
 1.025755882263184
 0.3832559585571289
 0.2492530345916748
 0.2336559295654297
 0.4121050834655762
 0.3448059558868408
 1.436866998672485
 1.051954984664917
 1.088149070739746
 0.377443790435791
 0.2993137836456299
 0.2212381362915039
 0.1660740375518799
 0.2954111099243164
 0.1316080093383789
 0.0757138729095459
 0.04759693145751953
 0.06981992721557617
 0.1318290233612061
 0.06433200836181641
 0.06516909599304199
 0.10921311378479
 0.1102340221405029
 0.1046288013458252
 0.06517386436462402
 0.3547728061676025
 0.08845996856689453
 0.03129100799560547
 0.01440310478210449
 0.1207289695739746
 0.03071403503417969
 0.0140380859375
 0.09896016120910645
 0.1380069255828857
 0.09383511543273926
 0.04770708084106445
 0.0197150707244873
 2.845977067947388
 0.3734540939331055
 0.1262829303741455
 0.2489249706268311
 0.1090438365936279
 1.865808963775635
 0.1391270160675049
 0.109673023223877
 0.06543207168579102
 0.1891341209411621
 0.1543159484863281
 0.09369897842407227
 0.2551050186157227
 0.03141498565673828
 1.426741123199463
 0.1432359218597412
 0.13173508644104
 0.1091699600219727
 0.1265130043029785
 0.1214709281921387
 0.07022404670715332
 0.0261847972869873
 0.09794211387634277
 1.52169394493103
 0.786653995513916
 0.3955070972442627
 0.3162989616394043
 0.4396259784698486
 0.1709640026092529
 0.1493790149688721
 0.109065055847168
 0.1692531108856201
 0.03687500953674316
 0.04758095741271973
 0.09264492988586426
 0.1076879501342773
 0.3109469413757324
 0.1091070175170898
 0.2443199157714844
 0.08123183250427246
 0.114616870880127
 0.1550090312957764
 0.08681392669677734
 0.2155270576477051
 0.1259410381317139
 0.07716107368469238
 0.1150598526000977
 1.559023857116699
 0.2049970626831055
 0.2108809947967529
 0.4223179817199707
 0.03066802024841309
 0.114703893661499
 0.03087902069091797
 0.4061439037322998
 0.2097160816192627
 0.03637099266052246
 0.6695740222930908
 0.1481869220733643
 0.0195620059967041
 0.02009105682373047
 0.05304503440856934
 1.496625900268555
 0.2154719829559326
 0.1593887805938721
 0.2107930183410645
 0.5152370929718018
 0.1150250434875488
 0.004185199737548828
 0.008669137954711914
 0.2493999004364014
 0.02522706985473633
 0.7232251167297363
 0.3404688835144043
 0.1426980495452881
 0.3834788799285889
 0.389739990234375
 0.08815503120422363
 0.1316239833831787
 0.1145792007446289
 1.539891004562378
 0.1654288768768311
 0.2280490398406982
 0.0532689094543457
 0.06458592414855957
 0.05354809761047363
 0.09224796295166016
 0.1091289520263672
 0.05863404273986816
 0.03675413131713867
 0.1315810680389404
 0.008666038513183594
 0.03269505500793457
 1.497366905212402
 0.1373250484466553
 0.03629207611083984
 0.3443589210510254
 0.1818611621856689
 0.1201848983764648
 0.2375779151916504
 0.3888070583343506
 0.1220269203186035
 0.1986739635467529
 0.1761960983276367
 0.09802484512329102
 0.18727707862854
 0.1882078647613525
 0.2174599170684814
 1.885183095932007
 0.1998558044433594
 0.3231709003448486
 0.2610878944396973
 0.09244608879089355
 0.4119138717651367
 0.138577938079834
 0.03632593154907227
 1.223940134048462
 0.1933701038360596
 0.2106890678405762
 0.053466796875
 0.09241318702697754
 0.2833080291748047
 0.1388530731201172
 0.23301100730896
 0.2448830604553223
 0.05320596694946289
 0.2941761016845703
 0.1653130054473877
 0.05879998207092285
 0.3059098720550537
 0.2382931709289551
 0.07004094123840332
 0.4785380363464355
 0.09819293022155762
 0.0375218391418457
 0.1708710193634033
 1.038689136505127
 0.02074790000915527
 0.1652910709381104
 0.04229211807250977
 1.442989110946655
 0.1273539066314697
 0.1048529148101807
 0.01433610916137695
 1.253976106643677
 0.08661603927612305
 0.03772211074829102
 0.06459498405456543
 0.09868597984313965
 0.01982712745666504
 0.008524894714355469
 0.02620291709899902
 1.348639965057373
 0.0368499755859375
 0.08156991004943848
 0.01985812187194824
 0.2721660137176514
 0.2108750343322754
 0.1259820461273193
 0.03151512145996094
 0.1091740131378174
 0.08672404289245605
 2.39498496055603
 0.08251214027404785
 0.05312705039978027
 0.2826840877532959
 0.1597027778625488
 1.170619964599609
 1.693443059921265
 0.4802861213684082
 0.1378769874572754
 1.741420030593872
 0.3161778450012207
 0.1825149059295654
 0.1098978519439697
 0.2047128677368164
 0.08673191070556641
 1.312434911727905
 0.104449987411499
 0.0762171745300293
 0.04245996475219727
 0.04905390739440918
 1.325744867324829
 0.1162748336791992
 0.1943120956420898
 0.09240412712097168
 0.05323886871337891
 0.05326986312866211
 0.008365869522094727
 0.2767519950866699
 0.2830641269683838
 0.06419897079467773
 0.3508448600769043
 0.6291689872741699
 0.227092981338501
 0.3558080196380615
 0.01971817016601562
 0.08818387985229492
 0.2554240226745605
 0.3503918647766113
 0.2774519920349121
 0.2218170166015625
 0.1877710819244385
 0.8272809982299805
 0.7605161666870117
 0.3057599067687988
 0.4695770740509033
 0.5017390251159668
 0.20477294921875
 0.05893588066101074
 0.2610549926757812
 0.0588219165802002
 1.179490089416504
 0.3000071048736572
 0.1419310569763184
 1.36465311050415
 0.1379930973052979
 0.1146719455718994
 0.05314898490905762
 0.1265239715576172
 0.1094651222229004
 1.632369041442871
 0.1258740425109863
 0.1327080726623535
 0.1594240665435791
 0.3109629154205322
 0.07558202743530273
 0.02671289443969727
 0.1427829265594482
 0.07564496994018555
 0.01405906677246094
 0.1481790542602539
 0.3383550643920898
 0.3382720947265625
 0.204096794128418
 0.1649048328399658
 0.1162660121917725
 0.5351650714874268
 0.5081899166107178
 0.427764892578125
 0.5300629138946533
 0.08665680885314941
 2.016862869262695
 0.1426200866699219
 0.08676385879516602
 1.483304023742676
 0.08216691017150879
 0.08186507225036621
 0.03085184097290039
 0.1654398441314697
 0.01404500007629395
 0.02551484107971191
 0.07010984420776367
 0.0430450439453125
 1.129157781600952
 1.141907930374146
 0
 3.426995992660522
 1.46920108795166
 2.5259108543396
 0.4857621192932129
 0.6039440631866455
 0.2179191112518311
 0.1261320114135742
 0.3279898166656494
 0.4355068206787109
 0.2834811210632324
 0.4400789737701416
 0.3455049991607666
 0.1162259578704834
 0.215745210647583
 0.5519759654998779
 0.2274680137634277
 0.9573850631713867
 0.4171829223632812
 0.4393129348754883
 0.1991031169891357
 0.08693099021911621
 0.0602729320526123
 0.3719849586486816
 0.2991781234741211
 0.009790897369384766
 0.1037509441375732
 0.1542661190032959
 1.54338002204895
 0.1873781681060791
 0.1091399192810059
 0.148205041885376
 0.3791911602020264
 0.04313778877258301
 0.04768991470336914
 0.1487560272216797
 0.01507186889648438
 1.196754932403564
 0.05984306335449219
 0
 0.5744450092315674
 2.035913944244385
 0.2506260871887207
 0.3397600650787354
 0.3235089778900146
 0.4790420532226562
 0.1596829891204834
 1.53759503364563
 0.1650190353393555
 0.2880709171295166
 0.3461759090423584
 0.05881381034851074
 0.1545941829681396
 0.1834480762481689
 0.08125782012939453
 0.07028889656066895
 0.1944220066070557
 0.02530312538146973
 0.01393914222717285
 0.131464958190918
 0.727168083190918
 0.2937190532684326
 0.3346052169799805
 0.08107089996337891
 0.08671903610229492
 0.8912489414215088
 0.4334349632263184
 0.1151700019836426
 0.1986160278320312
 0.065032958984375
 0.075531005859375
 1.093747138977051
 0.3886089324951172
 0.05876016616821289
 0.05408000946044922
 0.2210969924926758
 0.07543683052062988
 0.3999288082122803
 0.3960590362548828
 1.502848148345947
 0.461298942565918
 0.05867505073547363
 0.109760046005249
 0.2713761329650879
 0.2041728496551514
 0.04757189750671387
 0.9593870639801025
 0.0699620246887207
 0.1257522106170654
 0.1425361633300781
 0.01955199241638184
 0.01948404312133789
 1.922276973724365
 0.08130311965942383
 0.1323070526123047
 1.45234203338623
 0.8592178821563721
 1.208085060119629
 0.3895118236541748
 0.2113630771636963
 1.286664009094238
 0.5005881786346436
 0.2098979949951172
 0.0245978832244873
 0.5436029434204102
 0.8272409439086914
 1.571591138839722
 0.2711629867553711
 0.3051929473876953
 1.518648862838745
 0.01956391334533691
 0.03073906898498535
 1.376662969589233
 0.004233837127685547
 0.06567096710205078
 0.06999015808105469
 0.255126953125
 0.1881649494171143
 0.2733280658721924
 0.1876761913299561
 0.2209699153900146
 1.285789012908936
 0.2047359943389893
 0.1827900409698486
 0.1484999656677246
 0.2939059734344482
 0.6419799327850342
 0.1988289356231689
 0.2439470291137695
 0.148472785949707
 0.105226993560791
 0.2436730861663818
 0.1375689506530762
 0.05721688270568848
 0.1596889495849609
 0.02020502090454102
 1.57256293296814
 0.009945869445800781
 0.05886101722717285
 1.207194089889526
 0.2678020000457764
 0.4230308532714844
 0.1091699600219727
 0.2444319725036621
 0.05884790420532227
 0.03718900680541992
 0.120485782623291
 0.1540870666503906
 0.08196902275085449
 0.2202050685882568
 0.1095809936523438
 0.03078603744506836
 0.3460168838500977
 0.4377779960632324
 1.821574926376343
 0.3014340400695801
 0.3386929035186768
 0.03645801544189453
 0.1820120811462402
 0.2567949295043945
 0.8423891067504883
 0.2324149608612061
 0.04773306846618652
 0.01364016532897949
 0.1763620376586914
 0.2896850109100342
 0.2604541778564453
 0.2640120983123779
 0.1224799156188965
 0.0435490608215332
 0.3238310813903809
 0.2214689254760742
 0.3498477935791016
 0.3444499969482422
 0.1780478954315186
 2.262356996536255
 0.299921989440918
 0.2888469696044922
 0.1650481224060059
 0.1260638236999512
 0.5086030960083008
 0.05874514579772949
 0.7035949230194092
 0.2440290451049805
 0.07570099830627441
 0.03160405158996582
 0.08255696296691895
 0.06618809700012207
 1.391721963882446
 0.09203982353210449
 0.1104409694671631
 0.03131008148193359
 0.0307459831237793
 1.300825834274292
 1.605470180511475
 0.07658505439758301
 0.08232808113098145
 1.610569000244141
 0.1208279132843018
 0.07689690589904785
 0.1485638618469238
 0.04836201667785645
 1.449205875396729
 1.466474056243896
 0.1652970314025879
 0.1430730819702148
 1.337430000305176
 0.02565097808837891
 0.1543080806732178
 0.1882281303405762
 0.07610297203063965
 0.04204583168029785
 0.008366107940673828
 0.04338884353637695
 1.317037105560303
 0.1430909633636475
 0.03634405136108398
 0.06018400192260742
 0.04767107963562012
 0.1482470035552979
 1.186473846435547
 0.5410521030426025
 0.2896039485931396
 0.2174310684204102
 0.9656710624694824
 0.222769021987915
 0.2277719974517822
 0.3790879249572754
 0.2270548343658447
 0.1383259296417236
 0.1612648963928223
 0.160679817199707
 0.2211790084838867
 0.2785980701446533
 0.1944470405578613
 0.1889991760253906
 0.1038639545440674
 0.1818180084228516
 0.3339049816131592
 0.3969018459320068
 0.08684492111206055
 0.1607611179351807
 0.2167720794677734
 0.3794400691986084
 0.3895480632781982
 0.1486039161682129
 0.11586594581604
 0.1719100475311279
 0.2937901020050049
 0.1091201305389404
 1.272424936294556
 3.454063892364502
 0.1162040233612061
 0.04328799247741699
 0.3553040027618408
 0.2545759677886963
 0.2042269706726074
 0.2546689510345459
 0.1269869804382324
 0.2367148399353027
 0.2216699123382568
 0.02575802803039551
 0.01960206031799316
 0.1595821380615234
 0.0761568546295166
 1.499598979949951
 0.3168020248413086
 0.4797530174255371
 1.168024063110352
 0.551638126373291
 0.4901909828186035
 0.3568320274353027
 0.8272089958190918
 0.07557201385498047
 0.1259109973907471
 0.05970501899719238
 0.07563114166259766
 0.008355140686035156
 0.2884600162506104
 0.4507670402526855
 0.1097149848937988
 1.127262115478516
 0.1369459629058838
 0.02624893188476562
 0.2604250907897949
 0.2668581008911133
 0.4224069118499756
 0.333082914352417
 0.4744629859924316
 0.3620429039001465
 0.3114218711853027
 0.05910420417785645
 0.1430249214172363
 0.3951740264892578
 0.42848801612854
 0.1203291416168213
 0.2719910144805908
 0.1834449768066406
 0.4292359352111816
 0.1036319732666016
 0.1049280166625977
 0.02096295356750488
 1.444583892822266
 0.1385560035705566
 0.08824896812438965
 0.01432704925537109
 0.0154271125793457
 1.074235916137695
 0.0370938777923584
 1.235754013061523
 0.1488909721374512
 0.1884279251098633
 0.4174258708953857
 0.1485810279846191
 0.3625469207763672


# name: avgTeste
# type: scalar
0.3285422191619873


# name: antecipatedresponseT
# type: matrix
# rows: 1
# columns: 2
 3 3


