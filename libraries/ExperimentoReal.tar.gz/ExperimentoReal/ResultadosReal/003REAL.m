# Created by Octave 4.2.2, Fri Nov 06 11:43:26 2020 -03 <root@patricia-P5K-SE>
# name: SUBJECT
# type: sq_string
# elements: 1
# length: 3
003


# name: age
# type: sq_string
# elements: 1
# length: 2
28


# name: vet
# type: matrix
# rows: 1
# columns: 6
 1 1 2 2 3 3


# name: rvet
# type: matrix
# rows: 1
# columns: 6
 1 3 2 6 4 5


# name: response
# type: cell
# rows: 6
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt1
# type: matrix
# rows: 6
# columns: 1
 1.034904003143311
 0.5272960662841797
 0.4671611785888672
 0.3841590881347656
 0.3610539436340332
 0.2714600563049316


# name: antecipatedresponse
# type: matrix
# rows: 0
# columns: 0


# name: avg
# type: scalar
0.507672389348348


# name: seq
# type: matrix
# rows: 1
# columns: 750
 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 2 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3 1 2 2 1 2 2 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 3 1 2 2 1 2 3


# name: responseTeste
# type: cell
# rows: 750
# columns: 1
# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 2 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 1 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: matrix
# rows: 1
# columns: 2
 3 2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3





# name: rt2
# type: matrix
# rows: 750
# columns: 1
 0.3554239273071289
 0.1986498832702637
 0.3394980430603027
 0.2771670818328857
 0.2839260101318359
 0.2213699817657471
 0.27134108543396
 0.3604278564453125
 0.282926082611084
 0.3723058700561523
 0.2211771011352539
 0.2595338821411133
 0.3102269172668457
 0.2714979648590088
 0.137347936630249
 0.2264010906219482
 0.2091290950775146
 0.253870964050293
 0.2875461578369141
 0.2605350017547607
 0.2432918548583984
 0.2600979804992676
 0.1313979625701904
 0.1662259101867676
 0.254828929901123
 0.2818021774291992
 0.2003369331359863
 0.1984930038452148
 0.2036049365997314
 0.1605610847473145
 0.2765219211578369
 0.2273960113525391
 0.1981959342956543
 0.2314960956573486
 0.2705569267272949
 0.2262029647827148
 0.2482120990753174
 0.1758060455322266
 0.2147409915924072
 0.2211418151855469
 0.1087031364440918
 0.09760713577270508
 0.1588890552520752
 0.08298802375793457
 0.136713981628418
 0.1764039993286133
 0.1204228401184082
 0.0700831413269043
 0.1674039363861084
 0.08110904693603516
 0.2043519020080566
 0.2538039684295654
 0.1936399936676025
 0.2316031455993652
 0.1980540752410889
 0.2205879688262939
 0.1985979080200195
 0.2656278610229492
 0.2046160697937012
 0.2938189506530762
 0.2043261528015137
 0.1987810134887695
 0.1092901229858398
 0.2032999992370605
 0.1593630313873291
 0.1664669513702393
 0.1422009468078613
 0.153378963470459
 0.06436395645141602
 0.09757208824157715
 0.04744601249694824
 0.04215693473815918
 0.0756831169128418
 0.03664398193359375
 0.04831600189208984
 0.09876894950866699
 0.05292081832885742
 0.03068304061889648
 0.06547284126281738
 0.05332803726196289
 0.1538097858428955
 0.2614719867706299
 0.1426041126251221
 0.2216479778289795
 0.09274601936340332
 0.08759093284606934
 0.09332489967346191
 0.1257269382476807
 0.09957003593444824
 0.1595139503479004
 0.2048690319061279
 0.1089768409729004
 0.09761595726013184
 0.1603960990905762
 0.08096408843994141
 0.04182195663452148
 0.1149251461029053
 0.05316591262817383
 0.1817781925201416
 0.1649730205535889
 0.06415200233459473
 0.03197097778320312
 0.1337828636169434
 0.1089119911193848
 0.09932088851928711
 0.1258549690246582
 0.09774994850158691
 0.0926048755645752
 0.1152658462524414
 0.07545089721679688
 0.1039009094238281
 0.09760689735412598
 0.06978392601013184
 0.1031920909881592
 0.05894684791564941
 0.09227895736694336
 0.01456594467163086
 0.06992602348327637
 0.04229497909545898
 0.1758930683135986
 0.2099969387054443
 0.1317691802978516
 0.07606697082519531
 0.1540291309356689
 0.01963305473327637
 0.08114504814147949
 0.07560896873474121
 0.01474881172180176
 0.07613992691040039
 0.1089560985565186
 0.05887317657470703
 0.04764199256896973
 0.09229302406311035
 0.04760503768920898
 0.01389098167419434
 0.1648828983306885
 0.1266098022460938
 0.1817710399627686
 0.2655620574951172
 0.2787399291992188
 0.2038841247558594
 0.2830569744110107
 0.1591088771820068
 0.1668269634246826
 0.2375648021697998
 0.2093269824981689
 0.1813759803771973
 0.06409502029418945
 0.08691501617431641
 0.1589150428771973
 0.3200619220733643
 0.220789909362793
 0.186967134475708
 0.2594630718231201
 0.0824129581451416
 0.2484450340270996
 0.1652519702911377
 0.09295988082885742
 0.2147979736328125
 0.2387001514434814
 0.1201260089874268
 0.0920259952545166
 0.1596741676330566
 0.1164641380310059
 0.08815884590148926
 0.08682799339294434
 0.08115696907043457
 0.04181098937988281
 0.1034669876098633
 0.06412887573242188
 0.08636188507080078
 0.07569408416748047
 0.02506399154663086
 0.0087738037109375
 0.1047618389129639
 0.08788800239562988
 0.06509518623352051
 0.08200502395629883
 0.0478360652923584
 0.05873584747314453
 0.1198198795318604
 0.09751200675964355
 0.136681079864502
 0.05850601196289062
 0.03706812858581543
 6.345189094543457
 0.4714560508728027
 0.2479248046875
 0.1200211048126221
 0.06959700584411621
 1.794737100601196
 0.2816910743713379
 0.2317650318145752
 0.1495418548583984
 0.0482330322265625
 0.09794807434082031
 1.642237901687622
 0.1989850997924805
 0.125446081161499
 0.03666210174560547
 0.05376696586608887
 0.03642797470092773
 0.02506113052368164
 0.1978700160980225
 0.2541408538818359
 0.2874829769134521
 0.1365368366241455
 0.2593879699707031
 0.1198890209197998
 0.1424298286437988
 0.09195685386657715
 0.08657002449035645
 0.1755530834197998
 0.08655691146850586
 0.01984715461730957
 0.008558034896850586
 0.04904294013977051
 0.1198451519012451
 0.08629608154296875
 0.04757308959960938
 0.04724788665771484
 1.776530027389526
 0.1983211040496826
 0.1199250221252441
 0.1041140556335449
 0.1588239669799805
 0.008559942245483398
 0.02519416809082031
 0.1149179935455322
 0.07028889656066895
 0.10359787940979
 0.1591358184814453
 0.03128790855407715
 0.4249250888824463
 0.3263421058654785
 0.09753203392028809
 0.214630126953125
 0.1087489128112793
 0.06962203979492188
 0.09754514694213867
 0.08680605888366699
 0.07027602195739746
 0.1041178703308105
 0.07715010643005371
 1.506308078765869
 0.142326831817627
 0.1532661914825439
 0.08112406730651855
 0.09280800819396973
 0.1259419918060303
 0.04197001457214355
 0.198613166809082
 0.7569549083709717
 0.3429789543151855
 0.2149441242218018
 0.2873179912567139
 0.1980531215667725
 0.1373939514160156
 0.1256239414215088
 0.1091489791870117
 0.2163608074188232
 0.1367990970611572
 0.1156158447265625
 0.04853200912475586
 0.03655505180358887
 0.008316993713378906
 1.448477029800415
 0.3374519348144531
 0.0417931079864502
 0.01951479911804199
 0.04185199737548828
 0.01530289649963379
 0.01545619964599609
 0.04189205169677734
 0.009287834167480469
 0.3894758224487305
 0.2985599040985107
 0.109032154083252
 0.2376220226287842
 0.2148451805114746
 0.03691697120666504
 0.1033439636230469
 0.0307011604309082
 0.04768800735473633
 0.0307159423828125
 0.171212911605835
 0.04401206970214844
 0.1433870792388916
 0.1872060298919678
 0.02510190010070801
 0.06407999992370605
 0.08645987510681152
 0.08094596862792969
 0.06457614898681641
 0.1036088466644287
 0.0475001335144043
 0.1033248901367188
 0.08153486251831055
 0.07665896415710449
 0.1209840774536133
 0.3270208835601807
 0.04457306861877441
 0.1945991516113281
 0.2305839061737061
 0.0372779369354248
 0.2273709774017334
 0.2053549289703369
 0.04751300811767578
 0.1535370349884033
 0.1147079467773438
 0.01397395133972168
 0.08797812461853027
 0.06429195404052734
 1.082865953445435
 0.08107209205627441
 0.1262500286102295
 1.271365165710449
 0.1034200191497803
 0.06980204582214355
 0.1038789749145508
 0.0864870548248291
 0.1994290351867676
 0.1200900077819824
 0.0866389274597168
 0.0929419994354248
 0.09307622909545898
 1.287735939025879
 0.03626489639282227
 0.119938850402832
 0.05986595153808594
 0.08652114868164062
 1.35868501663208
 1.165133953094482
 0.1934621334075928
 0.05882596969604492
 0.5321319103240967
 0.109004020690918
 0.08674001693725586
 0.1159980297088623
 0.2539708614349365
 0.06418418884277344
 0.1539580821990967
 0.05960988998413086
 0.05930900573730469
 0.06449604034423828
 0.09271717071533203
 0.04187583923339844
 0.368865966796875
 0.1318469047546387
 0.1089680194854736
 0.09805607795715332
 0.09260296821594238
 0.05895900726318359
 0.06418704986572266
 0.1094589233398438
 0.01947999000549316
 0.1704330444335938
 0.09221506118774414
 0.1091349124908447
 0.01410484313964844
 0.06977105140686035
 1.154571056365967
 0.02523899078369141
 0.1653921604156494
 0.1595549583435059
 0.09260416030883789
 0.1091649532318115
 0.1423149108886719
 0.1813769340515137
 0.5559959411621094
 0.3261260986328125
 0.1756560802459717
 0.2202720642089844
 0.2387659549713135
 0.1538589000701904
 0.1425280570983887
 0.08637785911560059
 0.164654016494751
 0.0923919677734375
 0.1198978424072266
 0.09949517250061035
 0.114293098449707
 0.05320501327514648
 0.09254193305969238
 0.09202408790588379
 0.09283113479614258
 0.1366260051727295
 0.07117486000061035
 1.165724039077759
 0.4303379058837891
 0.1165909767150879
 0.06409406661987305
 0.08290505409240723
 0.08798098564147949
 0.4554679393768311
 0.2223429679870605
 0.1264801025390625
 0.0476691722869873
 0.1812598705291748
 0.05935406684875488
 1.328513145446777
 0.06431698799133301
 0.1486551761627197
 0.1091399192810059
 0.0699310302734375
 0.04199695587158203
 0.1032760143280029
 0.0201270580291748
 0.06527495384216309
 0.09236001968383789
 0.1369960308074951
 0.4525368213653564
 0.2875378131866455
 0.1702539920806885
 0.1592049598693848
 0.110231876373291
 0.1816170215606689
 0.05317187309265137
 0.01975083351135254
 0.10896897315979
 0.09202885627746582
 0.05518007278442383
 0.1146340370178223
 0.1422641277313232
 0.02527689933776855
 0.1150269508361816
 0.07620716094970703
 0.03079104423522949
 0.06443881988525391
 0.1256608963012695
 0.01392817497253418
 0.136909008026123
 0.08653402328491211
 0.04753303527832031
 0.05868196487426758
 0.05912590026855469
 0.0307469367980957
 0.1088359355926514
 0.1810600757598877
 1.184674978256226
 0.04760384559631348
 0.0596771240234375
 1.45617413520813
 0.409398078918457
 0.2487289905548096
 1.53999400138855
 0.1653339862823486
 0.03697800636291504
 1.327547073364258
 0.2050938606262207
 0.2057108879089355
 0.103705883026123
 0.2959649562835693
 0.1212098598480225
 0.06420207023620605
 0.165226936340332
 0.1491198539733887
 1.365384817123413
 0.08658313751220703
 0.06980299949645996
 1.179636001586914
 0.2110300064086914
 0.1097040176391602
 0.01391100883483887
 0.03067207336425781
 0.02568793296813965
 1.180043935775757
 0.01949310302734375
 0.07028698921203613
 1.118327140808105
 0.2034649848937988
 0.1087028980255127
 0.0474550724029541
 0.08083796501159668
 0.03635811805725098
 0.05375289916992188
 0.06428098678588867
 0.07670283317565918
 0.03066611289978027
 0.1478979587554932
 0.253925085067749
 0.1870508193969727
 0.2150840759277344
 0.0931999683380127
 0.06984305381774902
 0.07074093818664551
 0.1259880065917969
 0.02124595642089844
 0.1312999725341797
 0.07241606712341309
 0.07036089897155762
 0.0536799430847168
 0.08647298812866211
 0.01389002799987793
 0.04754018783569336
 0.3753201961517334
 0.1086962223052979
 0.1367161273956299
 0.0199429988861084
 0.04189491271972656
 0.1310679912567139
 0.09203791618347168
 1.25800609588623
 0.08641195297241211
 0.05323290824890137
 1.024288177490234
 0.1711711883544922
 0.0762488842010498
 0.05441498756408691
 0.2431340217590332
 0.2544820308685303
 0.03080892562866211
 0.1205518245697021
 0.04232501983642578
 1.102179050445557
 0.0874941349029541
 0.07598686218261719
 1.009777069091797
 0.2279629707336426
 0.05860209465026855
 0.01434493064880371
 0.1030957698822021
 0.0590059757232666
 1.085253953933716
 1.126768827438354
 0.1090869903564453
 0.9740610122680664
 0.04759812355041504
 0.06997585296630859
 1.133517026901245
 0.2545948028564453
 0.09251689910888672
 0.07030606269836426
 0.02512097358703613
 1.253307104110718
 1.302288055419922
 0.3992459774017334
 0.3722970485687256
 0.00922703742980957
 1.180431127548218
 0.2434289455413818
 0.02518701553344727
 0.03113698959350586
 1.717134952545166
 0.2447240352630615
 1.062361001968384
 0.008450031280517578
 0.0305171012878418
 0.0758368968963623
 0.008619070053100586
 1.379940032958984
 0.2692329883575439
 0.1422619819641113
 0.8968691825866699
 0.1426339149475098
 0.2315781116485596
 1.012603044509888
 0.4052338600158691
 0.3326640129089355
 0.1433029174804688
 0.1716499328613281
 0.06984615325927734
 0.03275609016418457
 0.06415915489196777
 0.08268308639526367
 0.01399111747741699
 1.142335891723633
 0.03059601783752441
 0.03687000274658203
 0.008362054824829102
 0.06965088844299316
 0.009119987487792969
 0.01996707916259766
 0.03657913208007812
 1.082942962646484
 0.007760047912597656
 0.0251162052154541
 1.378245115280151
 0.9684710502624512
 0.08076190948486328
 0.06413602828979492
 0.03197598457336426
 0.4357688426971436
 0.03629708290100098
 0.09204888343811035
 0.5082571506500244
 0.05942487716674805
 0.1717278957366943
 0.1423890590667725
 0.09350490570068359
 0.09791779518127441
 0.05335712432861328
 0.02502179145812988
 0.05467605590820312
 0.1326661109924316
 0.04763412475585938
 0.1205019950866699
 0.0422208309173584
 0.03161787986755371
 1.080873966217041
 0.3490891456604004
 0.05292701721191406
 0.05329799652099609
 0.09192204475402832
 0.03630590438842773
 0.1199569702148438
 0.1983311176300049
 0.04746913909912109
 0.09228014945983887
 0.05300188064575195
 0.03637790679931641
 0.120596170425415
 0.0761268138885498
 0.04189586639404297
 0.3079071044921875
 0.0698089599609375
 0.07022905349731445
 0.09243917465209961
 0.1325109004974365
 0.01398110389709473
 0.1651341915130615
 0.04753804206848145
 0.008321046829223633
 0.06425309181213379
 0.1087338924407959
 0.03700518608093262
 0.0307319164276123
 0.09836387634277344
 1.142419099807739
 0.02521395683288574
 0.06978988647460938
 0.01578402519226074
 0.01420187950134277
 0.09826993942260742
 0.01389908790588379
 1.164568901062012
 0.05902695655822754
 0.02000117301940918
 0.03105783462524414
 0.1033930778503418
 0.06434392929077148
 0.1202449798583984
 0.04385113716125488
 0.04373598098754883
 1.148386001586914
 0.08657002449035645
 1.153321027755737
 1.237897157669067
 0.09322881698608398
 0.04180693626403809
 0.01970791816711426
 0.06595396995544434
 0.09306097030639648
 0.01962018013000488
 0.1381790637969971
 0.1705670356750488
 0.3243100643157959
 0.1314408779144287
 0.1426680088043213
 0.1144199371337891
 0.2514619827270508
 0.03636693954467773
 0.1991682052612305
 0.2151710987091064
 1.238298892974854
 0.2208521366119385
 0.1648330688476562
 0.198577880859375
 0.1886091232299805
 0.2834889888763428
 0.05299496650695801
 0.0145869255065918
 0.05988883972167969
 0.0699000358581543
 0.1815009117126465
 0.1153872013092041
 0.0973961353302002
 0.04756307601928711
 0.2208020687103271
 0.0530390739440918
 0.06467604637145996
 0.1310150623321533
 0.008420944213867188
 1.223546028137207
 0.06985616683959961
 0.01524686813354492
 0.09262394905090332
 0.09216499328613281
 0.003957033157348633
 0.114642858505249
 0.2430570125579834
 0.07024884223937988
 0.06442093849182129
 0.1149849891662598
 0.03809404373168945
 0.1986019611358643
 0.05331611633300781
 0.03067207336425781
 0.07649397850036621
 0.07670402526855469
 0.05428576469421387
 0.1193079948425293
 0.1090018749237061
 0.0473630428314209
 0.0809929370880127
 0.2153887748718262
 0.09207510948181152
 0.04743099212646484
 0.1311979293823242
 0.01996517181396484
 0.103334903717041
 0.0585172176361084
 0.008305072784423828
 0.1645040512084961
 0.3710548877716064
 0.03664803504943848
 0.1592040061950684
 0.05961203575134277
 0.05439901351928711
 0.01466584205627441
 0.06983518600463867
 0.1592850685119629
 1.633117198944092
 0.07718205451965332
 0.1327850818634033
 0.09364914894104004
 0.03624916076660156
 0.03626799583435059
 0.1267831325531006
 0.05170321464538574
 0.03098917007446289
 0.07589411735534668
 0.05360794067382812
 0.07561397552490234
 0.03655385971069336
 0.110292911529541
 1.272348165512085
 1.209434986114502
 0.05163717269897461
 0.01395797729492188
 1.295677900314331
 0.05301713943481445
 0.05394816398620605
 0.0587310791015625
 0.08685088157653809
 0.04747605323791504
 0.3100359439849854
 0.109022855758667
 0.108936071395874
 0.1597509384155273


# name: avgTeste
# type: scalar
0.2117095486323039


# name: antecipatedresponseT
# type: matrix
# rows: 0
# columns: 0


